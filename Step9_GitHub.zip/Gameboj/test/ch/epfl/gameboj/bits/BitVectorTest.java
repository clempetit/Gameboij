/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.bits;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BitVectorTest {



    int posRnd = posRnd() + 1;

    private int posRnd() {
        int rnd = (int) (Math.random() * 100);
        return (rnd >= 0) ? rnd : -rnd;
    }

    @Test
    void contructorDontThrowException() {
        BitVector b = new BitVector(32 * posRnd, true);
        BitVector b2 = new BitVector(32 * posRnd, false);
        BitVector b3 = new BitVector(32 * posRnd);
    }

    @Test
    void extractThrowRightException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new BitVector(32 * posRnd).extractZeroExtended(2 * posRnd + 1, posRnd);
        });
    }

    @Test
    void contructorThrowRightException() {
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(-posRnd, true);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(posRnd * 2 + 1, true);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(0, true);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(-posRnd, false);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(posRnd * 2 + 1, false);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(0, false);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(-posRnd);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(posRnd * 2 + 1);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(0);
        });

    }

    @Test
    void constructCorrectValueWhenFalse() {

        BitVector b = new BitVector(32 * posRnd, false);
        for (int i = 0; i < 32 * posRnd; ++i) {
            assertEquals(false, b.testBit(i));
        }

        BitVector b1 = new BitVector(32 * posRnd);
        for (int i = 0; i < 32 * posRnd; ++i) {
            assertEquals(false, b1.testBit(i));
        }
    }

    @Test
    void constructCorrectValueWhenTrue() {

        BitVector b = new BitVector(32 * posRnd, true);
        for (int i = 0; i < 32 * posRnd; ++i) {
            assertEquals(true, b.testBit(i));

        }
    }

    @Test
    void testSize() {
        BitVector b = new BitVector(32 * posRnd, true);
        assertEquals(32 * posRnd, b.size());
    }

    @Test
    void TestvalueExtensionZero() {

        BitVector b = new BitVector(32 * posRnd, true);
        BitVector bExact = b.extractZeroExtended(0, 32 * posRnd);
        BitVector bBefore = b.extractZeroExtended(-32 * posRnd, 32 * posRnd);
        BitVector bAfter = b.extractZeroExtended(32 * posRnd, 32 * posRnd);
        for (int i = 0; i < 32 * posRnd; ++i) {

            assertEquals(b.testBit(i), bExact.testBit(i));

        }
        for (int i = 0; i < 32 * posRnd; ++i) {
            assertEquals(false, bBefore.testBit(i));
            assertEquals(false, bAfter.testBit(i));
        }

    }

    @Test
    void TestvalueWithExtensionWrrapped() {

        BitVector b = new BitVector(32 * posRnd, true);
        BitVector bExact = b.extractWrapped(0, 32 * posRnd);
        BitVector bBefore = b.extractWrapped(-posRnd, 32 * posRnd);
        BitVector bAfter = b.extractWrapped(32 * posRnd, 32 * posRnd);
        for (int i = 0; i < 32 * posRnd; ++i) {
            assertEquals(b.testBit(i), bExact.testBit(i));
        }
        for (int i = 0; i < 32 * posRnd; ++i) {

            assertEquals(b.testBit(i), bAfter.testBit(i));
            assertEquals(b.testBit((32 * posRnd - posRnd + i) % (32 * posRnd)), bBefore.testBit(i));
        }

    }

    @Test
    void TestBitThrowRightException() {
        BitVector b = new BitVector(32 * posRnd);
        assertThrows(IllegalArgumentException.class, () -> {
            b.testBit(-posRnd);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            b.testBit(32 * posRnd);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            b.testBit(32 * posRnd + posRnd);
        });
    }

    @Test
    void TestBitDontThrowException() {
        BitVector b = new BitVector(32 * posRnd);
        for (int i = 0; i < 32 * posRnd; ++i) {
            b.testBit(i);
        }
    }

    @Test
    void TestNot() {
        BitVector b = new BitVector(32 * posRnd, false);
        BitVector b1 = new BitVector(32 * posRnd, true);
        for (int i = 0; i < 32 * posRnd; ++i) {
            assertEquals(true, b.not().testBit(i));
            assertEquals(false, b1.not().testBit(i));
        }
    }

    @Test
    void TestAnd() {
        BitVector b0 = new BitVector(32 * posRnd, false);
        BitVector b1 = new BitVector(32 * posRnd, true);
        for (int i = 0; i < 32 * posRnd; ++i) {

            assertEquals(false, b0.and(b1).testBit(i));
            assertEquals(false, b0.and(b0).testBit(i));
            assertEquals(true, b1.and(b1).testBit(i));
        }
    }

    @Test
    void TestOr() {
        BitVector b0 = new BitVector(32 * posRnd, false);
        BitVector b1 = new BitVector(32 * posRnd, true);
        for (int i = 0; i < 32 * posRnd; ++i) {

            assertEquals(true, b0.or(b1).testBit(i));
            assertEquals(false, b0.or(b0).testBit(i));
            assertEquals(true, b1.or(b1).testBit(i));
        }
    }

    @Test
    void TestShift() {

        BitVector b = new BitVector(32 * posRnd, true);

        BitVector b1 = new BitVector.Builder(32 * posRnd).setByte(4 * posRnd - 1, 0b10000000).build();

        for (int i = 0; i < 32 * posRnd; ++i) {
            assertEquals(true, b1.shift(-32 * posRnd + 1 + i).testBit(i));

        }
        for (int i = 0; i < 32 * posRnd; ++i) {
            assertEquals(false, b.shift(-32 * posRnd).testBit(i));
            assertEquals(false, b.shift(32 * posRnd).testBit(i));
        }
        assertEquals(b, b.shift(0));
    }

    @Test
    void TestEqualsOverriding() {
        BitVector b1 = new BitVector(32 * posRnd, true);
        BitVector b0 = new BitVector(32 * posRnd, false);

        assertEquals(true, b1.equals(b1));
        assertEquals(false, b0.equals(b1));

    }

    @Test
    void TestBuilderConstructorThrowRightException() {

        assertThrows(IllegalArgumentException.class, () -> {
            BitVector v = new BitVector.Builder(-posRnd).build();
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector v = new BitVector.Builder(2 * posRnd + 1).build();
        });

    }

    @Test
    void logicOperatorThrowRightException() {
        assertThrows(NullPointerException.class, () -> {
            new BitVector(32 * posRnd).and(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new BitVector(32 * posRnd).and(new BitVector(32 * posRnd * 2));
        });
        assertThrows(NullPointerException.class, () -> {
            new BitVector(32 * posRnd).or(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new BitVector(32 * posRnd).or(new BitVector(32 * posRnd * 2));
        });
    }

    @Test
    void BuilderThrowRightexceptionAfterBuild() {
        assertThrows(IllegalStateException.class, () -> {
            BitVector.Builder b = new BitVector.Builder(32);
            BitVector v = b.build();
            b.setByte(0, 0);

        });
        assertThrows(IllegalStateException.class, () -> {
            BitVector.Builder b = new BitVector.Builder(32);
            BitVector v = b.build();
            b.build();
        });

    }

    @Test
    void TestBuilderConstructorWorks() {
        int a = 0b00000000_11111111_11001100_01010101;
        BitVector v = new BitVector.Builder(32).setByte(0, 0b01010101).setByte(1, 0b11001100).setByte(3, 0b00000000)
                .build();

        for (int i = 0; i < 16; ++i) {

            assertEquals(Bits.test(a, i), v.testBit(i));
            assertEquals(false, v.testBit(16 + i));
        }

    }

    @Test
    void setbyteThrowRightException() {
        int a = 0b00000000_11111111_11001100_01010101;

        assertThrows(IndexOutOfBoundsException.class, () -> {
            BitVector v = new BitVector.Builder(32).setByte(5, 0b01010101).build();
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector v = new BitVector.Builder(32).setByte(0, 0b110101011).build();
        });
    }

}