/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.bits;

import java.util.List;

public class BitVectorTest2 {
    public static void main(String[] args) {
        BitVector v1 = new BitVector(32, true);
        BitVector v2 = v1.extractZeroExtended(32, -17).not();
        BitVector v3 = v2.extractWrapped(64, 11);
        for (BitVector v: List.of(v1, v2, v3))
          System.out.println(v);
    }
}
