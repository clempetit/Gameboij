package ch.epfl.gameboj.component.cpu;


import static org.junit.Assert.assertEquals;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;


import ch.epfl.gameboj.Bus;

import ch.epfl.gameboj.bits.Bits;

import ch.epfl.gameboj.component.cpu.Alu;

import ch.epfl.gameboj.component.cpu.Cpu;

import ch.epfl.gameboj.component.cpu.Opcode;

import ch.epfl.gameboj.component.memory.Ram;

import ch.epfl.gameboj.component.memory.RamController;


class CpuTest4 {


void afficher(Cpu cpu) {

int[] tab = cpu._testGetPcSpAFBCDEHL();

System.out.println("PC : " + tab[0]);

System.out.println("SP: " + tab[1]);

System.out.println("A : " + tab[2]);

System.out.println("F : " + tab[3]);

System.out.println("B : " + tab[4]);

System.out.println("C : " + tab[5]);

System.out.println("D : " + tab[6]);

System.out.println("E : " + tab[7]);

System.out.println("H : " + tab[8]);

System.out.println("L : " + tab[9]);


}


@Test

void ADD_A_N8onTrivialValue() {


Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);


cpu.attachTo(bus);

rc.attachTo(bus);

bus.write(0, 0b11000110); // opcode ADD

bus.write(1, 0b00000000);

cpu.cycle(0); //A = 0b0


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b1000_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

void ADD_A_N8onNonTrivialValue1() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

bus.write(0, 00_111_110); // store pc+1 dans A

bus.write(1, 0x10);

bus.write(2, 0b11000110); // add

bus.write(3, 0x15);

toCycle(3, cpu); //A = 0x10 + 0x15;

assertEquals(0x25, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

void ADD_A_N8onNonTrivialValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

bus.write(0, 00_111_110); // store pc+1 dans A

bus.write(1, 0x10);

bus.write(2, 0b11000110); // add

bus.write(3, 0x80);

toCycle(3, cpu); //A = 0x10 + 0x15;

assertEquals(0x90, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0x50, cpu._testGetPcSpAFBCDEHL()[3]); //fanions


bus.write(0, 00_111_110); // store pc+1 dans A

bus.write(1, 0x08);

bus.write(2, 0b11000110); // add

bus.write(3, 0x08);

toCycle(3, cpu); //A = 0x10 + 0x15;

assertEquals(0x10, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0x20, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}


public void toCycle(int v, Cpu cpu) {

for (int i = 0; i <= v; ++i) {

cpu.cycle(i);

}

}

@Test

void ADD_A_R8onTrivialValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);


cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, 0b10000_000); // opcode ADD + B

bus.write(1, 0b00000000);//trivial

cpu.cycle(0); //A = 0b0

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b1000_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

void ADD_A_R8onNonTrivialValue1() {


Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_A_N8.encoding); // store pc+1 dans A

bus.write(1, 0x10);

bus.write(2, Opcode.LD_B_N8.encoding); // store pc+1 dans B

bus.write(3, 0x15);

bus.write(4, Opcode.ADD_A_B.encoding); // add

toCycle(4, cpu);


assertEquals(0x25, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

void ADD_A_R8onNonTrivialValue2() {


Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, 0b00_111_110); // store pc+1 dans A

bus.write(1, 0b1111_1111);

bus.write(2, 0b00_000_110); // store pc+1 dans B

bus.write(3, 0b1);

bus.write(4, 0b10000_000); // add

toCycle(4, cpu); //A = 0x10 + 0x15;


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b1011_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}


@Test

void ADD_A_R8onNonTrivialValue3() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, 0b00_111_110); // store pc+1 dans A

bus.write(1, 0x08);

bus.write(2, 0b00_000_110); // store pc+1 dans B

bus.write(3, 0x08);

bus.write(4, 0b10000_000); // add

toCycle(4, cpu); //A = 0x10 + 0x15;


assertEquals(0x10, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0x20, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void ADD_A_HLRonTrivialValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, 0b10000_110); // opcode ADD + B

cpu.cycle(0); //A = 0b0

assertEquals(0b10000_110, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b000_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void ADD_A_HLRonNonTrivialValue1() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//LD r16, n16 00rr0001

bus.write(0, 0b00_10_0001); 

bus.write(1, 0x20); //address HL

bus.write(2, 0x3A); // address HL

bus.write(0x3A20, 0b1110_1111); // [HL]

bus.write(3, 0b00_111_110); // store pc+1 dans A

bus.write(4, 0b1000);

bus.write(5, 0b1000_0110); // add 

toCycle(5, cpu);


assertEquals(0b1111_0111, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b0010_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void ADD_A_HLRonNonTrivialValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, 0b00_10_0001); 

bus.write(1, 0x20); //address HL

bus.write(2, 0x3A); // address HL

bus.write(0x3A20, 0b1111_1111); // [HL]

bus.write(3, 0b00_111_110); // store pc+1 dans A

bus.write(4, 0b1);

bus.write(5, 0b1000_0110); // add 

toCycle(5, cpu);

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b1011_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void ADD_A_HLRonNonTrivialValue3() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, 0b00_10_0001); 

bus.write(1, 0x20); //address HL

bus.write(2, 0x3A); // address HL

bus.write(0x3A20, 0b1000_0111); // [HL]

bus.write(3, 0b00_111_110); // store pc+1 dans A

bus.write(4, 0b1000);

bus.write(5, 0b1000_0110); // add 

toCycle(5, cpu);

assertEquals(0b1000_1111, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b0000_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void INC_R8onTrivialValue() {



Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);


cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, 0b00_111_100); // opcode inc in A

cpu.cycle(0); //A = 0b0


assertEquals(0b1, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b000_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void INC_R8onNonTrivialValue1() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

 

bus.write(0, 0b00_111_110); // store pc+1 dans A

bus.write(1, 0b1111_1111);

bus.write(2, 0b00_111_100); // opcode inc in A


toCycle(5, cpu);


assertEquals(0b0, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b1010_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void INC_R8onNonTrivialValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, 0b00_111_110); // store pc+1 dans A

bus.write(1, 0b0000_1111);

bus.write(2, 0b00_111_100); // opcode inc in A

toCycle(5, cpu);

assertEquals(0b0001_0000, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b0010_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void INC_HLRonTrivialValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);


cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0,  Opcode.INC_HLR.encoding); // opcode inc in [HL]

cpu.cycle(0); //A = 0b0

assertEquals(0b0011_0101, bus.read((cpu._testGetPcSpAFBCDEHL()[8]) << 8) + cpu._testGetPcSpAFBCDEHL()[9]);

assertEquals(0b0000_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void INC_HLRonNonTrivialValue1() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


//LD r16, n16 00rr0001

bus.write(0, 0b00_10_0001); 

bus.write(1, 0x20); //address HL

bus.write(2, 0x3A); // address HL

bus.write(0x3A20, 0b1111_1111); // [HL]

bus.write(3,  Opcode.INC_HLR.encoding); //


toCycle(5, cpu);


assertEquals(0b0, bus.read((cpu._testGetPcSpAFBCDEHL()[8] << 8) + cpu._testGetPcSpAFBCDEHL()[9]));

assertEquals(0b1010_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void INC_HLRonNonTrivialValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


//LD r16, n16 00rr0001

bus.write(0, 0b00_10_0001); 

bus.write(1, 0x20); //address HL

bus.write(2, 0x3A); // address HL

bus.write(0x3A20, 0b0000_1111); // [HL]

bus.write(3, 0b0011_0100); //

toCycle(5, cpu);

assertEquals(0b0001_0000, bus.read((cpu._testGetPcSpAFBCDEHL()[8] << 8) + cpu._testGetPcSpAFBCDEHL()[9]));

assertEquals(0b0010_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}


@Test

public void INC_R16SP_onTrivialValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.INC_SP.encoding);

toCycle(0, cpu);


assertEquals(1, cpu._testGetPcSpAFBCDEHL()[1]);

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void INC_R16SP_onNonTrivialValue1() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

bus.write(0, Opcode.LD_SP_N16.encoding);

bus.write(1, 0b1111_1111);

bus.write(2, 0b1111_1111);

bus.write(3, Opcode.INC_SP.encoding);


toCycle(4, cpu);

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[1]);

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void INC_R16SP_onNonTrivialValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

bus.write(0, Opcode.LD_SP_N16.encoding);

bus.write(1, 0b1000_1001);

bus.write(2, 0b1000_1001);

bus.write(3, Opcode.INC_SP.encoding);

toCycle(4, cpu);


assertEquals(0b1000_1001_1000_1010, cpu._testGetPcSpAFBCDEHL()[1]);

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

}

@Test

public void ADD_HL_R16SP_onTrivialValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.ADD_SP_N.encoding);

cpu.cycle(0);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[1]);

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[3]); //fanions


}

@Test

public void ADD_HL_R16SP_onNonTrivialValue1() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_SP_N16.encoding);

bus.write(1, 0b1111_1111);

bus.write(2, 0b1111_1111);

bus.write(3, Opcode.ADD_SP_N.encoding);

bus.write(4, 1);

toCycle(6, cpu);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[1]);

assertEquals(0b0011_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions


}

@Test

public void ADD_HL_R16SP_onNonTrivialValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_SP_N16.encoding);

bus.write(1, 0b000_1111);

bus.write(2, 0b0);

bus.write(3, Opcode.ADD_SP_N.encoding);

bus.write(4, 0b11110001); //complement à deux de 0b1111 pour des bytes


toCycle(6, cpu);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[1]);

assertEquals(0b00110000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions


}

@Test

public void LD_HLSP_S8_onTrivialValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_HL_SP_N8.encoding);

cpu.cycle(0);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[8]); // H

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[9]); // L

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[3]); //fanions


}

@Test

public void LD_HLSP_S8_onNonTrivialValue1() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_SP_N16.encoding);

bus.write(1, 0b000_1111);

bus.write(2, 0b0);

bus.write(3, Opcode.LD_HL_SP_N8.encoding);

bus.write(4, 0b11110001);


cpu.cycle(0);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[8]); // H

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[9]); // L

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[3]); //fanions


}

@Test

public void LD_HLSP_S8_onNonTrivialValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_SP_N16.encoding);

bus.write(1, 0b1111_1111);

bus.write(2, 0b1100_0001);

bus.write(3, Opcode.LD_HL_SP_N8.encoding);

bus.write(4, 0b1);


toCycle(5, cpu);


assertEquals(0b1100_0010, cpu._testGetPcSpAFBCDEHL()[8]); // H

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[9]); // L

assertEquals(0b0011_0000, cpu._testGetPcSpAFBCDEHL()[3]); //fanions

//attention revoir définitions des fanions pas certain de ce que j'ai fait

}


/*

* ------------------- SOUSTRATIONS -------------------

*/


@Test

public void SUB_A_n8_worksOnTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.SUB_A_N8.encoding);

cpu.cycle(0);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b1100_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void SUB_A_n8_worksOnNonTrivalValue1() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0b1111_0001);

bus.write(2, Opcode.SUB_A_N8.encoding);

bus.write(3, 1);

toCycle(3, cpu);


assertEquals(0b1111_0000, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b0100_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void SUB_A_n8_worksOnNonTrivalValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0b0);

bus.write(2, Opcode.SUB_A_N8.encoding);

bus.write(3, 1);

toCycle(3, cpu);


assertEquals(0b1111_1111, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b0111_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void SBC_A_n8_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


//cpu.setFlags(0b0001_000);

bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0x01);

bus.write(2, Opcode.SBC_A_N8.encoding);

bus.write(3, 0x01);

//cpu.setFlags(0b0001_0000);

toCycle(3, cpu);


assertEquals(0xFF, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0x70, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void SUB_A_R8_worksOnTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.SUB_A_A.encoding);

cpu.cycle(0);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b1100_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void SUB_A_R8_worksOnNonTrivalValue1() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0b1111_1111);

bus.write(2, Opcode.LD_B_N8.encoding);

bus.write(3, 0b0000_1111);

bus.write(4, Opcode.SUB_A_B.encoding);


toCycle(5, cpu);


assertEquals(0b1111_0000, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b0100_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void SUB_A_R8_worksOnNonTrivalValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0b0001_0111);

bus.write(2, Opcode.LD_B_N8.encoding);

bus.write(3, 0b0000_1000);

bus.write(4, Opcode.SUB_A_B.encoding);

toCycle(5, cpu);


assertEquals(0b0000_1111, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b0110_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void SBC_A_R8_worksOnNonTrivalValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0x01);

bus.write(2, Opcode.LD_B_N8.encoding);

bus.write(3, 0x01);

//cpu.setFlags(0b0001_0000);

bus.write(4, Opcode.SBC_A_B.encoding);


toCycle(5, cpu);


assertEquals(0xFF, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0x70, cpu._testGetPcSpAFBCDEHL()[3]);

}


@Test

public void SUB_A_HLR_worksOnTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_HL_N16.encoding);

bus.write(1, 0xC7);

bus.write(2, 0xFF);

bus.write(3, Opcode.SUB_A_HLR.encoding);

toCycle(6, cpu);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b1100_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}


@Test

public void SUB_A_HLR_worksOnNonTrivalValue1() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0x10);

bus.write(2, Opcode.LD_HL_N16.encoding);

bus.write(3, 0xC3);

bus.write(4, 0x78);

bus.write( 0x78C3, 0x80);

bus.write(5, Opcode.SUB_A_HLR.encoding);

toCycle(5, cpu);


assertEquals(0x90, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0x50, cpu._testGetPcSpAFBCDEHL()[3]);

}


@Test

public void SBC_A_HLR_worksOnNonTrivalValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0x01);

bus.write(2, Opcode.LD_HL_N16.encoding);

bus.write(3, 0xC3);

bus.write(4, 0x78);

bus.write( 0x78C3, 0x01);

//cpu.setFlags(0b0001_0000);

bus.write(5, Opcode.SBC_A_HLR.encoding);

toCycle(5, cpu);


assertEquals(0xFF, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0x70, cpu._testGetPcSpAFBCDEHL()[3]);

}


@Test

public void DEC_R8_worksOnTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.DEC_A.encoding);


cpu.cycle(0);


assertEquals(0b1111_1111, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b0110_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}


@Test

public void DEC_R8_worksOnNonTrivalValue1() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0b0001_0000);

bus.write(2, Opcode.DEC_A.encoding);


toCycle(6, cpu);


assertEquals(0b0000_1111, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b0110_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}


@Test

public void DEC_R8_worksOnNonTrivalValue2() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0b1111_1111);

bus.write(2, Opcode.DEC_A.encoding);


toCycle(6, cpu);


assertEquals(0b1111_1110, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b0100_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void DEC_HLR_worksOnTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);



bus.write(0, Opcode.DEC_HLR.encoding);

toCycle(6, cpu);


assertEquals(0b110100, bus.read((cpu._testGetPcSpAFBCDEHL()[8] <<8) + cpu._testGetPcSpAFBCDEHL()[9]));

assertEquals(0b0100_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void DEC_HLR_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_HL_N16.encoding);

bus.write(1, 0x12);

bus.write(2, 0xC9);

bus.write(0xC912, 0b0001_0000);

bus.write(3, Opcode.DEC_HLR.encoding);


toCycle(6, cpu);

assertEquals(0b0000_1111, bus.read((cpu._testGetPcSpAFBCDEHL()[8] <<8) + cpu._testGetPcSpAFBCDEHL()[9]));

assertEquals(0b0110_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void CP_A_n8_worksOnTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);



bus.write(0, Opcode.CP_A_N8.encoding);


toCycle(6, cpu);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b1100_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void CP_A_n8_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0x10);

bus.write(2, Opcode.CP_A_N8.encoding);

bus.write(3, 0x80);


toCycle(6, cpu);


assertEquals(0x10, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0x50, cpu._testGetPcSpAFBCDEHL()[3]);

}


@Test

public void CP_A_r8_worksOnTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);



bus.write(0, Opcode.CP_A_A.encoding);


toCycle(6, cpu);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b1100_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void CP_A_r8_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 0x10);

bus.write(2, Opcode.LD_B_N8.encoding);

bus.write(3, 0x80);

bus.write(4, Opcode.CP_A_B.encoding);


toCycle(6, cpu);


assertEquals(0x10, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0x50, cpu._testGetPcSpAFBCDEHL()[3]);

}


@Test

public void CP_A_HLR_worksOnTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_HL_N16.encoding);

bus.write(1, 0x77);

bus.write(2, 0x77);

bus.write(3, Opcode.CP_A_HLR.encoding);


toCycle(6, cpu);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0b1100_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void CP_A_HLR_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_HL_N16.encoding);

bus.write(1, 0x77);

bus.write(2, 0x77);

bus.write(0x7777, 0x80);

bus.write(3, Opcode.LD_A_N8.encoding);

bus.write(4, 0x10);

bus.write(5, Opcode.CP_A_HLR.encoding);


toCycle(6, cpu);


assertEquals(0x10, cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(0x50, cpu._testGetPcSpAFBCDEHL()[3]);

}

@Test

public void  DEC_R16_SP_worksOnTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_HL_N16.encoding);

bus.write(1, 1);

bus.write(2, 0);

bus.write(3, Opcode.DEC_HL.encoding);

////cpu.setFlags(0b1111_0000);

toCycle(6, cpu);


assertEquals(0, cpu._testGetPcSpAFBCDEHL()[8]);

assertEquals(0, cpu._testGetPcSpAFBCDEHL()[9]);

assertEquals(0b1111_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}


@Test

public void  DEC_R16_SP_worksOnNonTrivalValue() {

// ici tu dois la méthode sub doit prendre un entier de 8 bits max donc tu dois décomposer l address de R16 en deux différentes


Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);


bus.write(0, Opcode.LD_HL_N16.encoding);

bus.write(1, 0b0000_1111);

bus.write(2, 0b0000_1000);

bus.write(3, Opcode.DEC_HL.encoding);

////cpu.setFlags(0b1100_0000);

toCycle(6, cpu);


assertEquals(0b0000_1000, cpu._testGetPcSpAFBCDEHL()[8]);

assertEquals(0b0000_1110, cpu._testGetPcSpAFBCDEHL()[9]);

assertEquals(0b1100_0000, cpu._testGetPcSpAFBCDEHL()[3]);

}

/*

--------Pierre's tests ---------

*/

@Test

public void  AND_A_N8_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A",0b0101_1101);

bus.write(0, Opcode.AND_A_N8.encoding);

bus.write(1, 0b0100_1111);

cpu.cycle(0);

assertEquals(0b0100_1101,cpu._testGetPcSpAFBCDEHL()[2]);

bus.write(2, Opcode.AND_A_N8.encoding);

bus.write(3, 0b0010_1101);

cpu.cycle(2);

assertEquals(0b0000_1101,cpu._testGetPcSpAFBCDEHL()[2]);


}

@Test

public void  AND_A_R8_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A",0b0011_1100);

//cpu.writeInRegister("L",0b0101_1101);

bus.write(0, 0b10100101);//L

cpu.cycle(0);

assertEquals(0b0001_1100,cpu._testGetPcSpAFBCDEHL()[2]);

//cpu.writeInRegister("E",0b0101_1101);

bus.write(1, 0b10100011);//E

cpu.cycle(1);

assertEquals(0b0001_1100,cpu._testGetPcSpAFBCDEHL()[2]);

}

@Test

public void  AND_A_HL_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

////cpu.writeInRegister("A",0b0011_1100);

bus.write(0, 0b1010_0110);//BUS[HL]

cpu.cycle(0);

assertEquals(0b0010_0100,cpu._testGetPcSpAFBCDEHL()[2]);


}

@Test

public void  OR_A_N8_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

////cpu.writeInRegister("A",0b0101_1101);

bus.write(0, 0b1111_0110);

bus.write(1, 0b0100_1111);

cpu.cycle(0);

assertEquals((0b0101_1101|0b0100_1111),cpu._testGetPcSpAFBCDEHL()[2]);

bus.write(2, 0b1111_0110);

bus.write(3, 0b0010_1101);

cpu.cycle(2);

assertEquals((0b0101_1101|0b0100_1111)|0b0010_1101,cpu._testGetPcSpAFBCDEHL()[2]);

}

@Test

public void  OR_A_R8_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

////cpu.writeInRegister("A",0b0011_1100);

////cpu.writeInRegister("L",0b0101_1101);

bus.write(0, 0b10110101);//L

cpu.cycle(0);

assertEquals(0b0111_1101,cpu._testGetPcSpAFBCDEHL()[2]);

////cpu.writeInRegister("E",0b0101_1101);

bus.write(1, 0b10110011);//E

cpu.cycle(1);

assertEquals(0b0111_1101,cpu._testGetPcSpAFBCDEHL()[2]);

}

@Test

public void  OR_A_HL_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

////cpu.writeInRegister("A",0b0011_1100);

bus.write(0, 0b1011_0110);//BUS[HL]

cpu.cycle(0);

assertEquals(0b1011_1110,cpu._testGetPcSpAFBCDEHL()[2]);

}


@Test

public void  XOR_A_N8_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

////cpu.writeInRegister("A",0b0101_1101);

bus.write(0, 0b1110_1110);

bus.write(1, 0b0100_1111);

cpu.cycle(0);

assertEquals((0b0101_1101^0b0100_1111),cpu._testGetPcSpAFBCDEHL()[2]);

bus.write(2, 0b1110_1110);

bus.write(3, 0b0010_1101);

cpu.cycle(2);

assertEquals((0b0101_1101^0b0100_1111)^0b0010_1101,cpu._testGetPcSpAFBCDEHL()[2]);

}

@Test

public void  XOR_A_R8_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

////cpu.writeInRegister("A",0b0011_1100);

////cpu.writeInRegister("L",0b0101_1101);

bus.write(0, 0b10101101);//L

cpu.cycle(0);

assertEquals(0b0011_1100^0b0101_1101,cpu._testGetPcSpAFBCDEHL()[2]);

////cpu.writeInRegister("E",0b0101_1101);

bus.write(1, 0b10101011);//E

cpu.cycle(1);

assertEquals(((0b0011_1100^0b0101_1101)^0b0101_1101),cpu._testGetPcSpAFBCDEHL()[2]);

}

@Test

public void  XOR_A_HL_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

////cpu.writeInRegister("A",0b0011_1100);

bus.write(0, 0b1010_1110);//BUS[HL]

cpu.cycle(0);

assertEquals(0b0011_1100^0b1010_1110,cpu._testGetPcSpAFBCDEHL()[2]);

}


@Test

public void  CPL_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

////cpu.writeInRegister("A",0b0011_1100);

bus.write(0, 0b0010_1111);

cpu.cycle(0);

assertEquals(0b1100_0011,cpu._testGetPcSpAFBCDEHL()[2]);

}


@Test

public void  ROT_A_LEFT_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

////cpu.writeInRegister("A",0b0011_1100);

bus.write(0, 0b0000_0111);

cpu.cycle(0);

assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.LEFT,0b0011_1100,false)),cpu._testGetPcSpAFBCDEHL()[2]);

}


@Test

public void  ROT_A_RIGHT_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A",0b0011_1100);

bus.write(0, 0b0000_1111);

cpu.cycle(0);

assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.RIGHT,0b0011_1100,false)),cpu._testGetPcSpAFBCDEHL()[2]);

}


@Test

public void  ROT_A_LEFT_worksOnMaxValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A",0b1111_1111);

bus.write(0, 0b0000_0111);

cpu.cycle(0);

assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.LEFT,0b1111_1111,false)),cpu._testGetPcSpAFBCDEHL()[2]);

}


@Test

public void  ROT_A_RIGHT_worksOnMaxValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A",0b1111_1111);

bus.write(0, 0b0000_1111);

cpu.cycle(0);

assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.RIGHT,0b1111_1111,false)),cpu._testGetPcSpAFBCDEHL()[2]);

}


@Test

public void  ROT_A_LEFT_CARRY_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A",0b0011_1100);

bus.write(0, 0b0001_0111);

cpu.cycle(0);

assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.LEFT,0b0011_1100,true)),cpu._testGetPcSpAFBCDEHL()[2]);

}


@Test

public void  ROT_A_RIGHT_CARRY_worksOnNonTrivalValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A",0b0011_1100);

bus.write(0, 0b0001_1111);

cpu.cycle(0);

assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.RIGHT,0b0011_1100,true)),cpu._testGetPcSpAFBCDEHL()[2]);

}


@Test

public void  ROT_A_LEFT_CARRY_worksOnMaxValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A",0b1111_1111);

bus.write(0, 0b0001_0111);

cpu.cycle(0);

assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.LEFT,0b1111_1111,true)),cpu._testGetPcSpAFBCDEHL()[2]);

}


@Test

public void  ROT_A_RIGHT_CARRY_worksOnMaxValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A",0b1111_1111);

bus.write(0, 0b0001_1111);

cpu.cycle(0);

assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.RIGHT,0b1111_1111,true)),cpu._testGetPcSpAFBCDEHL()[2]);

}


@Test

public void  ROT_RU_LEFT_worksOnNonTrivialValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("D",0b1101_1001);

bus.write(0, 0xCB);

bus.write(1,0b0000_0010);//D

cpu.cycle(0);

cpu.cycle(1);

assertEquals(Bits.clip(8,Alu.unpackValue(Alu.rotate(Alu.RotDir.LEFT,0b1101_1001,false))),cpu._testGetPcSpAFBCDEHL()[6]);

}


@Test

public void  ROT_RU_LEFT_worksOnMaxValue() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("D",0b1111_1111);

bus.write(0, 0xCB);

bus.write(1,0b0000_0010);//D

cpu.cycle(0);

cpu.cycle(1);

assertEquals(Bits.clip(8,Alu.unpackValue(Alu.rotate(Alu.RotDir.LEFT,0b1111_1111,false))),cpu._testGetPcSpAFBCDEHL()[6]);

}


@Test

void RL_HLRRworksOnNonTrivial() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

bus.write(0,0xCB);

bus.write(1, 0b00111110);

cpu.cycle(0);

cpu.cycle(1);

assertEquals(101,bus.read(0));

}


@Test

void RL_HLRworksOnNonTrivial() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

bus.write(0, 74);

bus.write(1,0xCB);

bus.write(2, 0b00111110);

cpu.cycle(0);

cpu.cycle(1);

cpu.cycle(2);

assertEquals(37,bus.read(0));

}

@Test

void SET_U3_HLRworkOnNonTrivia() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

bus.write(0, 74);

bus.write(1, 0xCB);

bus.write(2,Opcode.SET_0_HLR.encoding);

cpu.cycle(0);

cpu.cycle(1);

cpu.cycle(2);

assertEquals(75, bus.read(0));

}


@Test

void SET_U3_HLR2workOnNonTrivia() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

bus.write(0, 74);

bus.write(1, 0xCB);

bus.write(2,0b11011110);

//cpu.cycle(0);

cpu.cycle(1);

cpu.cycle(2);

assertEquals(74, bus.read(0));

}


@Test

void SET_U3_HLR3workOnNonTrivia() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

bus.write(0, 74);

bus.write(1, 0xCB);

bus.write(2,0b11100110);

cpu.cycle(0);

cpu.cycle(1);

cpu.cycle(2);

assertEquals(0b1011010, bus.read(0));

}

@Test

void DAAworksOnNonTrivial() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

bus.write(0, Opcode.LD_A_N8.encoding);

bus.write(1, 73);

bus.write(4, Opcode.DAA.encoding);

cpu.cycle(0);

cpu.cycle(1);

cpu.cycle(2);

cpu.cycle(3);

cpu.cycle(4);

cpu.cycle(5);

cpu.cycle(6);

cpu.cycle(7);

cpu.cycle(8);

assertEquals(73,cpu._testGetPcSpAFBCDEHL()[2]);

}

@Test

void RES_U3_HLRworkOnNonTrivial() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

bus.write(0, 74);

bus.write(1, 0xCB);

bus.write(2,0b1000_1110);

cpu.cycle(0);

cpu.cycle(1);

cpu.cycle(2);


assertEquals(72, bus.read(0));

}


@Test

void RRAworksOnNonTrivial() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A", 74);

bus.write(0, 0x1F);

cpu.cycle(0);

assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.RIGHT, 74 ,true)), cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(Alu.unpackFlags(Alu.rotate(Alu.RotDir.RIGHT, 74 ,true)), cpu._testGetPcSpAFBCDEHL()[3]);


}

@Test

void RLAworksOnNonTrivial() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A", 74);

bus.write(0, 0xCB);

bus.write(1,Opcode.RL_A.encoding);

cpu.cycle(0);

cpu.cycle(1);

assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.LEFT, 74 ,true)), cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(Alu.unpackFlags(Alu.rotate(Alu.RotDir.LEFT, 74 ,true)), cpu._testGetPcSpAFBCDEHL()[3]);


}


@Test

void RRCAorksOnNonTrivial() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("A", 12);

bus.write(0, 0xCB);

bus.write(1,0b0000_1111);

cpu.cycle(0);

cpu.cycle(1);

assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.RIGHT, 12 ,false)), cpu._testGetPcSpAFBCDEHL()[2]);

assertEquals(Alu.unpackFlags(Alu.rotate(Alu.RotDir.RIGHT, 12 ,false)), cpu._testGetPcSpAFBCDEHL()[3]);


}


@Test

void RLCHworksOnNonTrivial() {

Cpu cpu = new Cpu();

Bus bus = new Bus();

Ram ram = new Ram(0xFFFF);

RamController rc = new RamController(ram, 0);

cpu.attachTo(bus);

rc.attachTo(bus);

//cpu.writeInRegister("L", 2);

bus.write(0, 0xCB);

bus.write(1,0b0000_0110);

bus.write(2, 193);

cpu.cycle(0);

System.out.println("start");

cpu.cycle(1);

cpu.cycle(2);

System.out.println("test :"+Alu.unpackValue(Alu.rotate(Alu.RotDir.LEFT,193 ,false)));

System.out.println("test2 :"+bus.read(2));

System.out.println("test3 :"+cpu._testGetPcSpAFBCDEHL()[8]); 

System.out.println("test4 :"+cpu._testGetPcSpAFBCDEHL()[9]);



assertEquals(Alu.unpackValue(Alu.rotate(Alu.RotDir.LEFT, 193,false)),bus.read(2));

assertEquals(Alu.unpackFlags(Alu.rotate(Alu.RotDir.LEFT, 193,false)), cpu._testGetPcSpAFBCDEHL()[3]);


}


}


