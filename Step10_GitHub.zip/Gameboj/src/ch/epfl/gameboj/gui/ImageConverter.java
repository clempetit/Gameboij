/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.gui;

import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;

public final class ImageConverter {
    
    WritableImage wI = new WritableImage(160, 144);
    
}
