/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.gui;
import java.io.File;
import java.util.List;

import ch.epfl.gameboj.GameBoy;
import ch.epfl.gameboj.Preconditions;
import ch.epfl.gameboj.component.cartridge.Cartridge;
import ch.epfl.gameboj.component.lcd.LcdController;
import javafx.application.Application;
import javafx.application.Application.Parameters;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;

public final class Main extends Application{

    public static void main(String[] args) {
        Application.launch(args);
      }

    @Override
    public void start(Stage stage) throws Exception {
        
        List<String> argList = getParameters().getRaw();
        
        if (argList.size() != 1)
            System.exit(1);
        
        File romFile = new File(argList.get(0));
        GameBoy gb = new GameBoy(Cartridge.ofFile(romFile));
        
        
        
        /////////////////////////////////////////////////////////
        Group root = new Group();
        Scene scene = new Scene(root);
        
        stage.setWidth(LcdController.LCD_WIDTH);
        stage.setHeight(LcdController.LCD_HEIGHT);
        stage.setScene(scene);
        stage.sizeToScene();
        stage.minWidthProperty().bind(scene.heightProperty());
        stage.minHeightProperty().bind(scene.widthProperty());
        stage.setTitle("gameboj");
        stage.show();
    }
    
    
}
