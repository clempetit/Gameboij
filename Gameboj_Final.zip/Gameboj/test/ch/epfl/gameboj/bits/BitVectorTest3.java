/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.bits;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Random;

import org.junit.jupiter.api.Test;

import ch.epfl.gameboj.bits.BitVector.Builder;

public class BitVectorTest3 {
    private int posRnd;

    @Test
    void boucle() {
        for (int i = 0; i < 50; ++i) {
            posRnd = new Random().nextInt(100) + 1;
            contructorDontThrowException();
            extractThrowRightException();
            contructorThrowRightException();
            constructCorrectValueWhenFalse();
            constructCorrectValueWhenTrue();
            testSize();
            TestvalueExtensionZero();
            TestvalueWithExtensionWrrapped();
            TestBitThrowRightException();
            TestBitDontThrowException();
            TestNot();
            TestAnd();
            TestOr();
            TestShift();
            TestEqualsOverriding();
            TestBuilderConstructorThrowRightException();
            logicOperatorThrowRightException();
            BuilderThrowRightexceptionAfterBuild();
            TestBuilderConstructorWorks();
            setbyteThrowRightException();
        }
    }

    private BitVector randomBitVector() {

        BitVector.Builder randomBitVector = new Builder(Integer.SIZE * posRnd);
        for (int i = 0; i < 4 * posRnd; ++i)
            randomBitVector.setByte(i, Bits.clip(8, new Random().nextInt(0b11111111)));
        return randomBitVector.build();
    }

    void contructorDontThrowException() {
        BitVector b = new BitVector(32 * posRnd, true);
        BitVector b2 = new BitVector(32 * posRnd, false);
        BitVector b3 = new BitVector(32 * posRnd);
        BitVector b4 = randomBitVector();
    }

    void extractThrowRightException() {
        assertThrows(IllegalArgumentException.class, () -> {
            randomBitVector().extractZeroExtended(2 * posRnd + 1, posRnd);
        });
    }

    void contructorThrowRightException() {
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(-posRnd, true);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(posRnd * 2 + 1, true);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(0, true);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(-posRnd, false);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(posRnd * 2 + 1, false);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(0, false);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(-posRnd);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(posRnd * 2 + 1);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector b = new BitVector(0);
        });

    }

    void constructCorrectValueWhenFalse() {

        BitVector b = new BitVector(32 * posRnd, false);
        for (int i = 0; i < 32 * posRnd; ++i) {
            assertEquals(false, b.testBit(i));
        }

        BitVector b1 = new BitVector(32 * posRnd);
        for (int i = 0; i < 32 * posRnd; ++i) {
            assertEquals(false, b1.testBit(i));
        }
    }

    void constructCorrectValueWhenTrue() {

        BitVector b = new BitVector(32 * posRnd, true);
        for (int i = 0; i < 32 * posRnd; ++i) {
            assertEquals(true, b.testBit(i));

        }
    }

    void testSize() {
        BitVector b = new BitVector(32 * posRnd, true);
        assertEquals(32 * posRnd, b.size());
    }

    void TestvalueExtensionZero() {

        BitVector b = randomBitVector();
        BitVector bExact = b.extractZeroExtended(b.size(), 0);
        BitVector bBefore = b.extractZeroExtended(b.size(), -b.size());
        BitVector bAfter = b.extractZeroExtended(b.size(), b.size());
        for (int i = 0; i < b.size(); ++i) {

            assertEquals(b.testBit(i), bExact.testBit(i));

        }
        for (int i = 0; i < b.size(); ++i) {
            assertEquals(false, bBefore.testBit(i));
            assertEquals(false, bAfter.testBit(i));
        }

    }

    void TestvalueWithExtensionWrrapped() {

        BitVector b = randomBitVector();
        BitVector bExact = b.extractWrapped(b.size(), 0);
        BitVector bBefore = b.extractWrapped(b.size(), -b.size() / Integer.SIZE);
        BitVector bAfter = b.extractWrapped(b.size(), b.size());
        for (int i = 0; i < b.size(); ++i) {
            assertEquals(b.testBit(i), bExact.testBit(i));
        }
        for (int i = 0; i < b.size(); ++i) {

            assertEquals(b.testBit(i), bAfter.testBit(i));
            assertEquals(b.testBit((b.size() - b.size() / Integer.SIZE + i) % (b.size())), bBefore.testBit(i));
        }

    }

    void TestBitThrowRightException() {
        BitVector b = randomBitVector();
        assertThrows(IllegalArgumentException.class, () -> {
            b.testBit(-b.size() / Integer.SIZE);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            b.testBit(b.size());
        });
        assertThrows(IllegalArgumentException.class, () -> {
            b.testBit(b.size() + b.size() / Integer.SIZE);
        });
    }

    void TestBitDontThrowException() {
        BitVector b = randomBitVector();
        for (int i = 0; i < b.size(); ++i) {
            b.testBit(i);
        }
    }

    private boolean not(boolean b) {
        return (b) ? false : true;
    }

    void TestNot() {
        BitVector b = randomBitVector();
        for (int i = 0; i < b.size(); ++i) {
            assertEquals(not(b.testBit(i)), b.not().testBit(i));

        }
    }

    void TestAnd() {
        BitVector b = randomBitVector();
        BitVector b1 = randomBitVector();
        for (int i = 0; i < b.size(); ++i) {
            assertEquals(b.testBit(i) && b1.testBit(i), b.and(b1).testBit(i));
        }
    }

    void TestOr() {
        BitVector b = randomBitVector();
        BitVector b1 = randomBitVector();
        for (int i = 0; i < b.size(); ++i) {
            assertEquals(b.testBit(i) || b1.testBit(i), b.or(b1).testBit(i));
        }
    }

    void TestShift() {

        BitVector b = randomBitVector();

        for (int i = 0; i < b.size() - posRnd; ++i) {
            assertEquals(b.testBit(i), b.shift(posRnd).testBit(i + posRnd));
            assertEquals(b.testBit(i + posRnd), b.shift(-posRnd).testBit(i));
        }
        for (int i = 0; i < posRnd; ++i) {
            assertEquals(false, b.shift(posRnd).testBit(i));

        }
        for (int i = b.size() - posRnd; i < posRnd; ++i) {
            assertEquals(false, b.shift(-posRnd).testBit(i));
        }
    }

    void TestEqualsOverriding() {

        BitVector b = randomBitVector();

        assertEquals(true, b.equals(b.and(new BitVector(b.size(), true))));
        assertEquals(false, b.equals(b.not()));

    }

    void TestBuilderConstructorThrowRightException() {

        assertThrows(IllegalArgumentException.class, () -> {
            BitVector v = new BitVector.Builder(-posRnd).build();
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector v = new BitVector.Builder(2 * posRnd + 1).build();
        });

    }

    void logicOperatorThrowRightException() {
        assertThrows(NullPointerException.class, () -> {
            randomBitVector().and(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            randomBitVector().and(new BitVector(Integer.SIZE * posRnd * 2));
        });
        assertThrows(NullPointerException.class, () -> {
            randomBitVector().or(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            randomBitVector().or(new BitVector(Integer.SIZE * posRnd * 2));
        });
    }

    void BuilderThrowRightexceptionAfterBuild() {
        assertThrows(IllegalStateException.class, () -> {
            BitVector.Builder b = new BitVector.Builder(Integer.SIZE * posRnd);
            BitVector v = b.build();
            b.setByte(posRnd, new Random().nextInt(0b11111111));

        });
        assertThrows(IllegalStateException.class, () -> {
            BitVector.Builder b = new BitVector.Builder(Integer.SIZE * posRnd);
            BitVector v = b.build();
            b.build();
        });

    }

    void TestBuilderConstructorWorks() {
        int a = new Random().nextInt();
        int c = new Random().nextInt();
        BitVector.Builder b = new BitVector.Builder(Integer.SIZE * 2);
        for (int i = 0; i < 4; ++i) {
            b.setByte(i, Bits.extract(a, i * 8, 8));
            b.setByte(i + 4, Bits.extract(c, i * 8, 8));
        }
        BitVector v = b.build();
        for (int i = 0; i < Integer.SIZE; ++i) {

            assertEquals(Bits.test(a, i), v.testBit(i));
            assertEquals(Bits.test(c, i), v.testBit(i + Integer.SIZE));

        }

    }

    void setbyteThrowRightException() {

        assertThrows(IndexOutOfBoundsException.class, () -> {
            BitVector v = new BitVector.Builder(32).setByte(5, 0b01010101).build();
        });
        assertThrows(IllegalArgumentException.class, () -> {
            BitVector v = new BitVector.Builder(32).setByte(0, 0b110101011).build();
        });
    }
}
