/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.animation.AnimationTimer;

public final class Example extends Application {
    public static void main(String[] args) {
      Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
      long start = System.nanoTime();
      AnimationTimer timer = new AnimationTimer() {
      @Override
      public void handle(long now) {
        long elapsed = now - start;
        System.out.printf("Temps écoulé : %.2f s%n",
                  elapsed / 1e9);
      }
        };
      timer.start();
    }
  }
