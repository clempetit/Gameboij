/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.component.cpu;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ch.epfl.gameboj.Bus;
import ch.epfl.gameboj.bits.Bits;
import ch.epfl.gameboj.component.cpu.Cpu;
import ch.epfl.gameboj.component.cpu.Opcode;
import ch.epfl.gameboj.component.memory.Ram;
import ch.epfl.gameboj.component.memory.RamController;

class CpuTest7 {

    @Test
    void JP_HL_WorksOnTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);

        bus.write(0, 0xCB);
        bus.write(1, Opcode.JP_HL.encoding);

        assertEquals(0, cpu._testGetPcSpAFBCDEHL()[0]);
    }

    @Test
    void JP_HL_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.LD_L_N8.encoding);
        bus.write(1, 120);
        bus.write(2, Opcode.JP_HL.encoding);
        cpu.cycle(0);
        cpu.cycle(1);
        cpu.cycle(2);
        assertEquals(120, cpu._testGetPcSpAFBCDEHL()[0]);
    }
    
    @Test
    void JP_N16_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.JP_N16.encoding);
        bus.write(1, 0b10010000);
        bus.write(2, 0b01111000);
        cpu.cycle(0);
        assertEquals(0b01111000_10010000, cpu._testGetPcSpAFBCDEHL()[0]);
    }
    
    @Test
    void JP_C_N16_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b0111_0000);
        bus.write(0, Opcode.JP_C_N16.encoding);
        bus.write(1, 0b10010000);
        bus.write(2, 0b01111000);
        cpu.cycle(0);
        assertEquals(0b01111000_10010000, cpu._testGetPcSpAFBCDEHL()[0]);
    }
    @Test
    void JP_NZ_N16_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.JP_NZ_N16.encoding);
        bus.write(1, 0b10010000);
        bus.write(2, 0b01111000);
        cpu.cycle(0);
        assertEquals(3, cpu._testGetPcSpAFBCDEHL()[0]);
    }@Test
    void JP_NC_N16_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.JP_NC_N16.encoding);
        bus.write(1, 0b10010000);
        bus.write(2, 0b01111000);
        cpu.cycle(0);
        assertEquals(Opcode.JP_NC_N16.totalBytes, cpu._testGetPcSpAFBCDEHL()[0]);
    }
    @Test
    void JP_Z_N16_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.JP_Z_N16.encoding);
        bus.write(1, 0b10010000);
        bus.write(2, 0b01111000);
        cpu.cycle(0);
        assertEquals(0b01111000_10010000, cpu._testGetPcSpAFBCDEHL()[0]);
    }
    @Test
    void JR_E8_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        System.out.println("JRE8");
        bus.write(0, Opcode.JR_E8.encoding);
        bus.write(1, 0b1000_1000);
        cpu.cycle(0);
        assertEquals(2+Bits.signExtend8(0b1000_1000), cpu._testGetPcSpAFBCDEHL()[0]);
    }
    @Test
    void JR_E8_C_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.JR_C_E8.encoding);
        bus.write(1, 0b1000_1000);
        cpu.cycle(0);
        assertEquals(2+Bits.signExtend8(0b1000_1000), cpu._testGetPcSpAFBCDEHL()[0]);
    }
    @Test
    void JR_E8_Z_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.JR_Z_E8.encoding);
        bus.write(1, 0b1000_1000);
        cpu.cycle(0);
        System.out.println(2+Bits.signExtend8(0b1000_1000));
        assertEquals(2+Bits.signExtend8(0b1000_1000), cpu._testGetPcSpAFBCDEHL()[0]);
    }
    @Test
    void JR_E8_NC_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.JR_NC_E8.encoding);
        bus.write(1, 0b1000_1000);
        cpu.cycle(0);
        assertEquals(Opcode.JR_NC_E8.totalBytes, cpu._testGetPcSpAFBCDEHL()[0]);
    }
    @Test
    void JR_E8_NZ_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.JR_NZ_E8.encoding);
        bus.write(1, 0b1000_1000);
        cpu.cycle(0);
        assertEquals(Opcode.JR_NZ_E8.totalBytes, cpu._testGetPcSpAFBCDEHL()[0]);
    }
    //needs SP set to 2
    @Test
    void CALL_N16_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.CALL_N16.encoding);
        System.out.println("test");
        bus.write(2,0b1111_1000);
        cpu.cycle(0);
        assertEquals(0b1111_1000_0000_0000,cpu._testGetPcSpAFBCDEHL()[0]);
    }
    @Test
    void CALL_NC_N16_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.CALL_NC_N16.encoding);
        bus.write(2,0b1111_1000);
        cpu.cycle(0);
        assertEquals(Opcode.CALL_NC_N16.totalBytes,cpu._testGetPcSpAFBCDEHL()[0]);
    }
    
    @Test
    void CALL_C_N16_WorksOnNonTrivialValue2() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.CALL_C_N16.encoding);
        bus.write(2,0b1111_1000);
        cpu.cycle(0);
        assertEquals(0b1111_1000_0000_0000,cpu._testGetPcSpAFBCDEHL()[0]);
    }
    @Test
    void CALL_Z_N16_WorksOnNonTrivialValue2() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.CALL_Z_N16.encoding);
        bus.write(2,0b1111_1111);
        cpu.cycle(0);
        assertEquals(0b1111_1111_0000_0000,cpu._testGetPcSpAFBCDEHL()[0]);
    }

    @Test
    void CALL_NZ_N16_WorksOnNonTrivialValue2() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b0111_0000);
        bus.write(0, Opcode.CALL_NZ_N16.encoding);
        bus.write(2,0b1111_1111);
        cpu.cycle(0);
        assertEquals(0b1111_1111_0000_0000,cpu._testGetPcSpAFBCDEHL()[0]);
    }
    
    @Test
    void RST_2_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.RST_2.encoding);
        cpu.cycle(0);
        assertEquals(16,cpu._testGetPcSpAFBCDEHL()[0]);
    }
    
    @Test
    void RST_5_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.RST_5.encoding);
        cpu.cycle(0);
        assertEquals(40,cpu._testGetPcSpAFBCDEHL()[0]);
    }
    
    @Test
    void RST_7_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.RST_7.encoding);
        cpu.cycle(0);
        assertEquals(56,cpu._testGetPcSpAFBCDEHL()[0]);
    }
    
    @Test
    void RET_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.RET.encoding);
        cpu.cycle(0);
        assertEquals(Opcode.RET.encoding,cpu._testGetPcSpAFBCDEHL()[0]);
    }
    
    @Test
    void RET_NC_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.RET_NC.encoding);
        cpu.cycle(0);
        assertEquals(Opcode.RET_NC.totalBytes,cpu._testGetPcSpAFBCDEHL()[0]);
    }
    
    @Test
    void RET_Z_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        //cpu.writeInF(0b1111_0000);
        bus.write(0, Opcode.RET_Z.encoding);
        cpu.cycle(0);
        assertEquals(Opcode.RET_Z.encoding,cpu._testGetPcSpAFBCDEHL()[0]);
    }
    
    @Test
    void EI_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.EI.encoding);
        cpu.cycle(0);
        //assertEquals(true,cpu.getIME());
    }
    
    @Test
    void DI_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.DI.encoding);
        cpu.cycle(0);
        //assertEquals(false,cpu.getIME());
    }
    
    @Test
    void EI_DI_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.EI.encoding);
        bus.write(1, Opcode.DI.encoding);
        cpu.cycle(0);
        //assertEquals(true,cpu.getIME());
        cpu.cycle(1);
        //assertEquals(false,cpu.getIME());
    }
    
    @Test
    void RETI_WorksOnNonTrivialValue() {
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);
        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.RETI.encoding);
        cpu.cycle(0);
        //assertEquals(true,cpu.getIME());
        assertEquals(Opcode.RETI.encoding,cpu._testGetPcSpAFBCDEHL()[0]);
        
    }

}