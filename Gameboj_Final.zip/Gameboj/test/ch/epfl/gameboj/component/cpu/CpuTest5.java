package ch.epfl.gameboj.component.cpu;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ch.epfl.gameboj.Bus;
import ch.epfl.gameboj.bits.Bits;
import ch.epfl.gameboj.component.memory.Ram;
import ch.epfl.gameboj.component.memory.RamController;

class CpuTest5 {

    private Bus connect(Cpu cpu, Ram ram) {
        RamController rc = new RamController(ram, 0);
        Bus b = new Bus();
        cpu.attachTo(b);
        rc.attachTo(b);
        return b;
    }

    private void cycleCpu(Cpu cpu, long cycles) {
        for (long c = 0; c < cycles; ++c)
            cpu.cycle(c);
    }
    
    private int[] step(Opcode opcode, int argument) {
        return new int[] {opcode.encoding, argument, opcode.totalBytes, opcode.cycles};
    }
    
    private int[] step(Opcode opcode) {
        return step(opcode, -1);
    }
    
    private int[] prefix(Opcode opcode) {
        return new int[] {0xCB, -1, 1, 0};
    }
    
    private int runSteps(Cpu cpu, Bus bus, int[][] steps) {
        int totalCycles = 0;
        int writeHead = 0;
        
        // Prepare the RAM
        for (int[] step : steps) {
            bus.write(writeHead++, step[0]);
            totalCycles += step[3];
            if (step[1] != -1) {
                if (step[2] == 2) {
                    bus.write(writeHead++, step[1]);
                } else if(step[2] == 3) {
                    bus.write(writeHead++, Bits.clip(8, step[1]));
                    bus.write(writeHead++, Bits.extract(step[1], 8, 8));
                }
            }
        }
        
        cycleCpu(cpu, totalCycles);
        return writeHead;
    }
    

    @Test
    void nopDoesNothing() {
        Cpu c = new Cpu();
        Ram r = new Ram(10);
        Bus b = connect(c, r);
        b.write(0, Opcode.NOP.encoding);
        cycleCpu(c, Opcode.NOP.cycles);
        assertArrayEquals(new int[] {1,0,0,0,0,0,0,0,0,0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForNOP() {
        Cpu c = new Cpu();
        Ram r = new Ram(10);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.NOP),
            step(Opcode.NOP),
            step(Opcode.NOP),
        });
        
        assertArrayEquals(new int[] {count, 0, 0, 0, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_R8_HLR() {
        Cpu c = new Cpu();
        Ram r = new Ram(256);
        Bus b = connect(c, r);
                
        // Write data at 0x9
        b.write(0xFF, 0x80);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_HL_N16, 0xFF),
            step(Opcode.LD_A_HLR),
            step(Opcode.LD_B_HLR),
            step(Opcode.LD_C_HLR),
            step(Opcode.LD_D_HLR),
            step(Opcode.LD_E_HLR),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x80, 0x00, 0x80, 0x80, 0x80, 0x80, 0x00, 0xFF}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_A_HLRI() {
        Cpu c = new Cpu();
        Ram r = new Ram(256);
        Bus b = connect(c, r);
        
        b.write(0xFE, 0x7F);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_HL_N16, 0xFE),
            step(Opcode.LD_A_HLRI, 1),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x7F, 0, 0, 0, 0, 0, 0, 0xFF}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_A_HLRD() {
        Cpu c = new Cpu();
        Ram r = new Ram(256);
        Bus b = connect(c, r);
        
        b.write(0xFE, 0x7F);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_HL_N16, 0xFE),
            step(Opcode.LD_A_HLRD, 1),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x7F, 0, 0, 0, 0, 0, 0, 0xFD}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_A_N8R() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        b.write(0xFF00, 0x90);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8R, 0),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x90, 0, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_A_CR() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        b.write(0xFF01, 0x90);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_C_N8, 0x01),
            step(Opcode.LD_A_CR),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x90, 0, 0, 0x01, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_A_N16R() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        b.write(0xFF07, 0x90);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N16R, 0xFF07),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x90, 0, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_A_BCR() {
        
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        b.write(0xFF08, 0x69);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_BC_N16, 0xFF08),
            step(Opcode.LD_A_BCR),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x69, 0, 0xFF, 0x08, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_A_DER() {
        
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        b.write(0xFF08, 0x69);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_DE_N16, 0xFF08),
            step(Opcode.LD_A_DER),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x69, 0, 0, 0, 0xFF, 0x08, 0, 0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_R8_N8() {
        Cpu c = new Cpu();
        Ram r = new Ram(256);
        Bus b = connect(c, r);
                
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 1),
            step(Opcode.LD_B_N8, 3),
            step(Opcode.LD_C_N8, 4),
            step(Opcode.LD_D_N8, 5),
            step(Opcode.LD_E_N8, 6),
            step(Opcode.LD_H_N8, 7),
            step(Opcode.LD_L_N8, 8),
        });
        
        assertArrayEquals(new int[] {count, 0, 1, 0, 3, 4, 5, 6, 7, 8}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_R16SP_N16() {
        
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_BC_N16, 0xFF69),
            step(Opcode.LD_DE_N16, 0xF869),
            step(Opcode.LD_HL_N16, 0xF769),
            step(Opcode.LD_SP_N16, 0xF669),
        });
        
       
        assertArrayEquals(new int[] {count, 0xF669, 0, 0, 0xFF, 0x69, 0xF8, 0x69, 0xF7, 0x69}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForPUSH_R16_POP_R16() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        b.write(0xFF07, 0x90);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_SP_N16, 0xFF02),
            step(Opcode.LD_BC_N16, 0xDEAD),
            step(Opcode.LD_DE_N16, 0xBEEF),
            step(Opcode.PUSH_DE),
            step(Opcode.PUSH_BC),
            step(Opcode.POP_DE),
            step(Opcode.POP_BC),
            step(Opcode.PUSH_BC)
        });
        
        assertArrayEquals(new int[] {count, 0xFF00, 0, 0, 0xBE, 0xEF, 0xDE, 0xAD, 0, 0}, c._testGetPcSpAFBCDEHL());
        assertEquals(0xBE, b.read(0xFF01));
        assertEquals(0xEF, b.read(0xFF00));
    }
    
    @Test
    void dispatchWorksForLD_HLR_R8() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
           step(Opcode.LD_HL_N16, 0xBABE),
           step(Opcode.LD_A_N8, 0xF7),
           step(Opcode.LD_HLR_A),
           step(Opcode.LD_HL_N16, 0xBABF),
           step(Opcode.LD_B_N8, 0x80),
           step(Opcode.LD_HLR_B),
        });
        
        assertArrayEquals(new int[] {count, 0, 0xF7, 0, 0x80, 0, 0, 0, 0xBA, 0xBF}, c._testGetPcSpAFBCDEHL());
        assertEquals(0xF7, b.read(0xBABE));
        assertEquals(0x80, b.read(0xBABF));
    }
    
    @Test
    void dispatchWorksForLD_HLRI_A() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);

        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_HL_N16, 0xBABE),
            step(Opcode.LD_A_N8, 0x90),
            step(Opcode.LD_HLRI_A),
         });
        
        assertArrayEquals(new int[] {count, 0, 0x90, 0, 0, 0, 0, 0, 0xBA, 0xBF}, c._testGetPcSpAFBCDEHL());
        assertEquals(0x90, b.read(0xBABE));
    }
    
    @Test
    void dispatchWorksForLD_HLRD_A() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);

        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_HL_N16, 0xBABE),
            step(Opcode.LD_A_N8, 0x90),
            step(Opcode.LD_HLRD_A),
         });
        
        assertArrayEquals(new int[] {count, 0, 0x90, 0, 0, 0, 0, 0, 0xBA, 0xBD}, c._testGetPcSpAFBCDEHL());
        assertEquals(0x90, b.read(0xBABE));
    }
    
    @Test
    void dispatchWorksForLD_N8R_A() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);

        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x90),
            step(Opcode.LD_N8R_A, 0xAB),
         });
        
        assertArrayEquals(new int[] {count, 0, 0x90, 0, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        assertEquals(0x90, b.read(0xFFAB));
    }
    
    @Test
    void dispatchWorksForLD_CR_A() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);

        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x90),
            step(Opcode.LD_C_N8, 0xAB),
            step(Opcode.LD_CR_A),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x90, 0, 0, 0xAB, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        assertEquals(0x90, b.read(0xFFAB));
    }
    
    @Test
    void dispatchWorksForLD_N16R_A() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);

        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x90),
            step(Opcode.LD_N16R_A, 0xDEAD),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x90, 0, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        assertEquals(0x90, b.read(0xDEAD));

    }
    
    @Test
    void dispatchWorksForLD_BCR_A() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_BC_N16, 0xBABE),
            step(Opcode.LD_A_N8, 0xBA),
            step(Opcode.LD_BCR_A),
        });
        
        assertArrayEquals(new int[] {count, 0, 0xBA, 0, 0xBA, 0xBE, 0, 0, 0, 0} , c._testGetPcSpAFBCDEHL());
        assertEquals(0xBA, b.read(0xBABE));
    }
    
    @Test
    void dispatchWorksForLD_DER_A() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_DE_N16, 0xBABE),
            step(Opcode.LD_A_N8, 0xBA),
            step(Opcode.LD_DER_A),
        });
        
        assertArrayEquals(new int[] {count, 0, 0xBA, 0, 0, 0, 0xBA, 0xBE, 0, 0} , c._testGetPcSpAFBCDEHL());
        assertEquals(0xBA, b.read(0xBABE));
    }
    
    @Test
    void dispatchWorksForLD_HLR_N8() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);

        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_HL_N16, 0xDEAD),
            step(Opcode.LD_HLR_N8, 0x70),
        });
        
        assertArrayEquals(new int[] {count, 0, 0, 0, 0, 0, 0, 0, 0xDE, 0xAD}, c._testGetPcSpAFBCDEHL());
        assertEquals(0x70, b.read(0xDEAD));
    }
    
    @Test
    void dispatchWorksForLD_N16R_SP() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_SP_N16, 0xBABE),
            step(Opcode.LD_N16R_SP, 0xDADE),
        });

        assertArrayEquals(new int[] {count, 0xBABE, 0, 0, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        assertEquals(0xBE, b.read(0xDADE));
        assertEquals(0xBA, b.read(0xDADF));
    }
    
    @Test
    void dispatchWorksForLD_R8_R8() {
        
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x11),
            step(Opcode.LD_B_A),
            step(Opcode.LD_C_B),
            step(Opcode.LD_D_C),
            step(Opcode.LD_E_D),
            step(Opcode.LD_H_E),
            step(Opcode.LD_L_H),
        });
       
        assertArrayEquals(new int[] {count, 0, 0x11, 0, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_SP_HL() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_HL_N16, 0xBEEF),
            step(Opcode.LD_SP_HL),
        });

        assertArrayEquals(new int[] {count, 0xBEEF, 0, 0, 0, 0, 0, 0, 0xBE, 0xEF}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForADD_A_R8() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x10),
            step(Opcode.LD_B_N8, 0x15),
            step(Opcode.ADD_A_B)
        });
        
        assertArrayEquals(new int[] {count, 0, 0x25, 0x00, 0x15, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        
        c = new Cpu();
        r = new Ram(65535);
        b = connect(c, r);
        
        count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x08),
            step(Opcode.LD_B_N8, 0x08),
            step(Opcode.ADD_A_B)
        });
        
        assertArrayEquals(new int[] {count, 0, 0x10, 0x20, 0x08, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        
        c = new Cpu();
        r = new Ram(65535);
        b = connect(c, r);
        
        count = runSteps(c, b, new int[][] {
            step(Opcode.SCF),
            step(Opcode.LD_A_N8, 0x80),
            step(Opcode.LD_B_N8, 0x7F),
            step(Opcode.ADC_A_B)
        });
        
        assertArrayEquals(new int[] {count, 0, 0x00, 0xB0, 0x7F, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForADD_A_N8() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x10),
            step(Opcode.ADD_A_N8, 0x15)
        });
        
        assertArrayEquals(new int[] {count, 0, 0x25, 0x00, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        
        c = new Cpu();
        r = new Ram(65535);
        b = connect(c, r);
        
        count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x08),
            step(Opcode.ADD_A_N8, 0x08),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x10, 0x20, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        
        c = new Cpu();
        r = new Ram(65535);
        b = connect(c, r);
        
        count = runSteps(c, b, new int[][] {
            step(Opcode.SCF),
            step(Opcode.LD_A_N8, 0x80),
            step(Opcode.ADC_A_N8, 0x7F),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x00, 0xB0, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForADD_A_HLR() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        b.write(0xBEEF, 0x08);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x08),
            step(Opcode.LD_HL_N16, 0xBEEF),
            step(Opcode.ADD_A_HLR)
        });
        
        assertArrayEquals(new int[] {count, 0, 0x10, 0x20, 0, 0, 0, 0, 0xBE, 0xEF}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForINC_R8() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.SCF),
            step(Opcode.LD_A_N8, 0),
            step(Opcode.LD_B_N8, 2),
            step(Opcode.LD_C_N8, 3),
            step(Opcode.LD_D_N8, 4),
            step(Opcode.LD_E_N8, 5),            
            step(Opcode.LD_H_N8, 254),            
            step(Opcode.LD_L_N8, 255),   
            step(Opcode.INC_A),
            step(Opcode.INC_B),
            step(Opcode.INC_C),
            step(Opcode.INC_D),
            step(Opcode.INC_E),
            step(Opcode.INC_H),
            step(Opcode.INC_L),
        });
        
        assertArrayEquals(new int[] {count, 0, 1, 0xB0, 3, 4, 5, 6, 255, 0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForINC_HLR() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        b.write(0xBEEF, 76);
        b.write(0xDEAD, 255);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.SCF),
            step(Opcode.LD_HL_N16, 0xBEEF),
            step(Opcode.INC_HLR),
            step(Opcode.LD_HL_N16, 0xDEAD),
            step(Opcode.INC_HLR),
        });
        
        assertArrayEquals(new int[] {count, 0, 0, 0xB0, 0, 0, 0, 0, 0xDE, 0xAD}, c._testGetPcSpAFBCDEHL());
        assertEquals(77, b.read(0xBEEF));
        assertEquals(0, b.read(0xDEAD));
    }
    
    @Test
    void dispatchWorksForINC_R16SP() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.SCF),
            step(Opcode.LD_BC_N16, 0xFFFE),
            step(Opcode.LD_DE_N16, 0xFFFF),
            step(Opcode.LD_SP_N16, 0xFFFE),
            step(Opcode.LD_HL_N16, 0xFFFF),
            step(Opcode.INC_BC),
            step(Opcode.INC_DE),
            step(Opcode.INC_SP),
            step(Opcode.INC_HL),
        });
        
        assertArrayEquals(new int[] {count, 0xFFFF, 0, 0x10, 0xFF, 0xFF, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForADD_HL_R16SP() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_HL_N16, 0x11FF),
            step(Opcode.LD_SP_N16, 0x0001),
            step(Opcode.ADD_HL_SP),
        });
        
        assertArrayEquals(new int[] {count, 1, 0, 0, 0, 0, 0, 0, 0x12, 0x00}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForLD_HLSP_S8() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_SP_N16, 0x11FF),
            step(Opcode.ADD_SP_N, 0xFF),
            step(Opcode.LD_HL_SP_N8, 0xFF),
        });
        
        assertArrayEquals(new int[] {count, 0x11FE, 0, 0x30, 0, 0, 0, 0, 0x11, 0xFD}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForSUB_A_R8() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x10),
            step(Opcode.LD_B_N8, 0x10),
            step(Opcode.SUB_A_B),
        });
        
        assertArrayEquals(new int[] {count, 0, 0, 0xC0, 0x10, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        
        c = new Cpu();
        r = new Ram(65535);
        b = connect(c, r);
        
        count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x10),
            step(Opcode.LD_C_N8, 0x80),
            step(Opcode.SUB_A_C),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x90, 0x50, 0, 0x80, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        
        c = new Cpu();
        r = new Ram(65535);
        b = connect(c, r);
        
        count = runSteps(c, b, new int[][] {
            step(Opcode.SCF),
            step(Opcode.LD_A_N8, 0x01),
            step(Opcode.LD_D_N8, 0x01),
            step(Opcode.SBC_A_D),
        });
        
        assertArrayEquals(new int[] {count, 0, 0xFF, 0x70, 0, 0, 0x01, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
    }
    
    @Test
    void dispatchWorksForSUB_A_N8() {
        Cpu c = new Cpu();
        Ram r = new Ram(65535);
        Bus b = connect(c, r);
        
        int count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x10),
            step(Opcode.SUB_A_N8, 0x10),
        });
        
        assertArrayEquals(new int[] {count, 0, 0, 0xC0, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        
        c = new Cpu();
        r = new Ram(65535);
        b = connect(c, r);
        
        count = runSteps(c, b, new int[][] {
            step(Opcode.LD_A_N8, 0x10),
            step(Opcode.SUB_A_N8, 0x80),
        });
        
        assertArrayEquals(new int[] {count, 0, 0x90, 0x50, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
        
        c = new Cpu();
        r = new Ram(65535);
        b = connect(c, r);
        
        count = runSteps(c, b, new int[][] {
            step(Opcode.SCF),
            step(Opcode.LD_A_N8, 0x01),
            step(Opcode.SBC_A_N8, 0x01),
        });
        
        assertArrayEquals(new int[] {count, 0, 0xFF, 0x70, 0, 0, 0, 0, 0, 0}, c._testGetPcSpAFBCDEHL());
    }
}
