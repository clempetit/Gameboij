/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.component.cpu;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import ch.epfl.gameboj.GameBoy;
import ch.epfl.gameboj.component.memory.Ram;
import ch.epfl.gameboj.component.memory.RamController;

class CpuTest8 {
    
    byte fibo_it[] = new byte[] {
            (byte)0x06, (byte)0x00, (byte)0x3e, (byte)0x01,
            (byte)0x0e, (byte)0x0a, (byte)0x57, (byte)0x80,
            (byte)0x42, (byte)0x0d, (byte)0xc2, (byte)0x06,
            (byte)0x00, (byte)0x76
          };
    
    byte tab[] = new byte[] {
            (byte)0x31, (byte)0xFF, (byte)0xFF, (byte)0x3E,
            (byte)0x0A, (byte)0xCD, (byte)0x09, (byte)0x00,
            (byte)0x76, (byte)0xFE, (byte)0x02, (byte)0xD8,
            (byte)0x28, (byte)0x1C, (byte)0x00, (byte)0x00, 
            (byte)0xC5, (byte)0xD5, (byte)0x3D, (byte)0x00,
            (byte)0x47, (byte)0xCD, (byte)0x09, (byte)0x00,
            (byte)0x4F, (byte)0x78, (byte)0x3D, (byte)0x47,
            (byte)0xCD, (byte)0x09, (byte)0x00, (byte)0x57,
            (byte)0x78, (byte)0x3D, (byte)0xCD, (byte)0x09,
            (byte)0x00, (byte)0x81, (byte)0x82, (byte)0xD1,
            (byte)0xC1, (byte)0xC9, (byte)0x3D, (byte)0xC9,
        };

    void $(byte[] program, int expect,int cycles) {
        
        GameBoy gameBoy = new GameBoy(null);
        
        Ram ram = new Ram(0xFFFF);
        RamController ramController = new RamController(ram,0);
        ramController.attachTo(gameBoy.bus());
        
        for(int i=0;i<program.length;i++) {
            gameBoy.bus().write(i, Byte.toUnsignedInt(program[i]));
        }
        
        
        gameBoy.runUntil(cycles);
        assertEquals(expect, gameBoy.cpu()._testGetPcSpAFBCDEHL()[2]);
    }
    
    @Test 
    void tuttiquanti(){
        
        $(fibo_it,89,300);
        $(tab,149,8000);
    }

}