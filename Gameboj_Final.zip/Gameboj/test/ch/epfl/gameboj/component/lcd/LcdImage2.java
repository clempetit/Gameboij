/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.component.lcd;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.Test;

import ch.epfl.gameboj.bits.BitVector;
import ch.epfl.gameboj.bits.BitVector.Builder;
import ch.epfl.gameboj.bits.Bits;

public class LcdImage2 {
    private int posRnd;
    private int size;

    List<LcdImageLine> lines;

    @Test
    void boucle() {
        for (int i = 0; i < 100; ++i) {
            posRnd = new Random().nextInt(100) + 1;
            size = posRnd * Integer.SIZE;
            lines = randomLines();

            constructor();
            testGet();
            overridingEquals();
            testBuilder();
        }
    }

    void constructor() {

        LcdImage image = new LcdImage(size, posRnd, lines);
        assertEquals(size, image.width());
        assertEquals(posRnd, image.height());
        assertEquals(size, image.width());

    }

    void testGet() {
        LcdImage image = new LcdImage(size, posRnd, lines);
        for (int y = 0; y < image.height(); ++y) {
            for (int x = 0; x < image.width(); ++x) {
                assertEquals((lines.get(y).msb().testBit(x) ? 1<<1 : 0) + (lines.get(y).lsb().testBit(x) ? 1 : 0),
                        image.get(x, y));
            }
        }

    }

    void overridingEquals() {
        LcdImage image1 = new LcdImage(size, posRnd, lines);
        LcdImage image2 = new LcdImage(size, posRnd, lines);
        LcdImage image3 = randomImage();
        assertEquals(true, image1.equals(image2));
        assertEquals(false, image1.equals(image3));

    }

    void testBuilder() {
        List<LcdImageLine> lines = new ArrayList();
        LcdImage.Builder imageb = new LcdImage.Builder(size, posRnd);
        for (int i = 0; i < posRnd; ++i) {
            lines.add(randomLine());
            imageb.setLine(i, lines.get(i));
        }
        LcdImage image = imageb.build();
        for (int y = 0; y < image.height(); ++y) {
            for (int x = 0; x < image.width(); ++x) {
                assertEquals((lines.get(y).msb().testBit(x) ? 1 << 1 : 0) + (lines.get(y).lsb().testBit(x) ? 1 : 0),
                        image.get(x, y));
            }
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private List<LcdImageLine> randomLines() {
        List<LcdImageLine> lines = new ArrayList<>();
        for (int i = 0; i < posRnd; ++i) {
            lines.add(randomLine());
        }
        return lines;
    }

    private BitVector randomBitVector() {

        BitVector.Builder randomBitVector = new Builder(Integer.SIZE * posRnd);
        for (int i = 0; i < 4 * posRnd; ++i)
            randomBitVector.setByte(i, Bits.clip(8, new Random().nextInt(0b11111111)));
        return randomBitVector.build();
    }

    private LcdImageLine randomLine() {
        return new LcdImageLine(randomBitVector(), randomBitVector(), randomBitVector());
    }

    private LcdImage randomImage() {
        List<LcdImageLine> lines = new ArrayList<>();
        for (int i = 0; i < posRnd; ++i) {
            lines.add(randomLine());
        }
        return new LcdImage(size, posRnd, lines);
    }
}
