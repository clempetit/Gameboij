/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.component.lcd;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ch.epfl.gameboj.bits.BitVector;

class LcdImageTest {

	@Test
	void joinTest() {
		

		BitVector v = new BitVector.Builder(32)
				  .setByte(0, 0b1111_0000)
				  .setByte(1, 0b1010_1010)
				  .setByte(2, 0b1100_1100)
				  .setByte(3, 0b1001_0101)
				  .build();
		
		BitVector v2 = new BitVector.Builder(32)
				  .setByte(0, 0b1111_0101)
				  .setByte(1, 0b0000_1010)
				  .setByte(2, 0b1101_1000)
				  .setByte(3, 0b1011_1101)
				  .build();
		BitVector v3 = new BitVector.Builder(32)
				  .setByte(0, 0b1011_0101)
				  .setByte(1, 0b1110_1010)
				  .setByte(2, 0b1001_1100)
				  .setByte(3, 0b0000_1010)
				  .build();
		
		BitVector v4 = new BitVector.Builder(32)
				  .setByte(0, 0b1111_1101)
				  .setByte(1, 0b1010_1111)
				  .setByte(2, 0b1011_1000)
				  .setByte(3, 0b1110_1010)
				  .build();
		
		BitVector msb = new BitVector.Builder(32)
				  .setByte(0, 0b1111_0000)
				  .setByte(1, 0b1010_1010)
				  .setByte(2, 0b1100_1100)
				  .setByte(3, 0b0000_0101)
				  .build();
		
		BitVector lsb = new BitVector.Builder(32)
				  .setByte(0, 0b1111_0101)
				  .setByte(1, 0b0000_1010)
				  .setByte(2, 0b1101_1000)
				  .setByte(3, 0b1110_1101)
				  .build();
		
		
		LcdImageLine line1 = new LcdImageLine(v,v2,v.or(v2));
		LcdImageLine line2 = new LcdImageLine(v3,v4,v3.or(v4));
		LcdImageLine line3 = line1.join(line2, 28);
		LcdImageLine line4 = line1.join(line2, 0);
		LcdImageLine line5 = line1.join(line2, 32);

		
		assertEquals(line3.msb().toString(),msb.toString());
		assertEquals(line3.lsb().toString(),lsb.toString());
		assertEquals(line3.opacity().toString(),msb.or(lsb).toString());

		assertEquals(line4.msb().toString(),line2.msb().toString());
		assertEquals(line4.lsb().toString(),line2.lsb().toString());
		assertEquals(line4.opacity().toString(),line2.opacity().toString());
		
		assertEquals(line5.msb().toString(),line1.msb().toString());
		assertEquals(line5.lsb().toString(),line1.lsb().toString());
		assertEquals(line5.opacity().toString(),line1.opacity().toString());
	}

	@Test
	void belowTest() {
		BitVector v = new BitVector.Builder(32)
				  .setByte(0, 0b1111_0000)
				  .setByte(1, 0b1010_1010)
				  .setByte(2, 0b1100_1100)
				  .setByte(3, 0b1001_0101)
				  .build();
		
		BitVector v2 = new BitVector.Builder(32)
				  .setByte(0, 0b1111_0101)
				  .setByte(1, 0b0000_1010)
				  .setByte(2, 0b1101_1000)
				  .setByte(3, 0b1011_1101)
				  .build();
		BitVector v3 = new BitVector.Builder(32)
				  .setByte(0, 0b1011_0101)
				  .setByte(1, 0b1110_1010)
				  .setByte(2, 0b1001_1100)
				  .setByte(3, 0b0000_1010)
				  .build();
		
		BitVector v4 = new BitVector.Builder(32)
				  .setByte(0, 0b1111_1101)
				  .setByte(1, 0b1010_1111)
				  .setByte(2, 0b1011_1000)
				  .setByte(3, 0b1110_1010)
				  .build();
		
		BitVector msb1 = new BitVector.Builder(32)
				  .setByte(0, 0b1011_0101)
				  .setByte(1, 0b1110_1010)
				  .setByte(2, 0b1101_1100)
				  .setByte(3, 0b0001_1111)
				  .build();
		
		BitVector lsb1 = new BitVector.Builder(32)
				  .setByte(0, 0b1111_1101)
				  .setByte(1, 0b1010_1111)
				  .setByte(2, 0b1111_1000)
				  .setByte(3, 0b1111_1111)
				  .build();
		
		LcdImageLine line1 = new LcdImageLine(v,v2,v.or(v2));
		LcdImageLine line2 = new LcdImageLine(v3,v4,v3.or(v4));
		//System.out.println(line2.opacity().toString());		//1110_1010_1011_1100_1110_1111_1111_1101
		
		LcdImageLine line3 = line1.below(line2);
		
		assertEquals(line3.msb().toString(),msb1.toString());
		assertEquals(line3.lsb().toString(),lsb1.toString());
		assertEquals(line3.opacity().toString(),line2.opacity().toString());


	}
	@Test
	void belowWithNewOpacityTest() {
		BitVector v = new BitVector.Builder(32)
				  .setByte(0, 0b1111_0000)
				  .setByte(1, 0b1010_1010)
				  .setByte(2, 0b1100_1100)
				  .setByte(3, 0b1001_0101)
				  .build();
		
		BitVector v2 = new BitVector.Builder(32)
				  .setByte(0, 0b1111_0101)
				  .setByte(1, 0b0000_1010)
				  .setByte(2, 0b1101_1000)
				  .setByte(3, 0b1011_1101)
				  .build();
		BitVector v3 = new BitVector.Builder(32)
				  .setByte(0, 0b1011_0101)
				  .setByte(1, 0b1110_1010)
				  .setByte(2, 0b1001_1100)
				  .setByte(3, 0b0000_1010)
				  .build();
		
		BitVector v4 = new BitVector.Builder(32)
				  .setByte(0, 0b1111_1101)
				  .setByte(1, 0b1010_1111)
				  .setByte(2, 0b1011_1000)
				  .setByte(3, 0b1110_1010)
				  .build();
		
		BitVector opacity = new BitVector.Builder(32)
				  .setByte(0, 0b1111_0000)
				  .setByte(1, 0b1100_1010)
				  .setByte(2, 0b1100_1110)
				  .setByte(3, 0b1111_0101)
				  .build();
		
		BitVector opacity2 = new BitVector.Builder(32)
				  .setByte(0, 0b1111_1111)
				  .setByte(1, 0b1111_1111)
				  .setByte(2, 0b1111_1111)
				  .setByte(3, 0b1111_1111)
				  .build();
		BitVector opacity3 = new BitVector.Builder(32)
				  .setByte(0, 0b0000_0000)
				  .setByte(1, 0b0000_0000)
				  .setByte(2, 0b0000_0000)
				  .setByte(3, 0b0000_0000)
				  .build();
		
		BitVector msb1 = new BitVector.Builder(32)
				  .setByte(0, 0b1011_0000)
				  .setByte(1, 0b1110_1010)
				  .setByte(2, 0b1000_1100)
				  .setByte(3, 0b0000_0000)
				  .build();	
		
		BitVector lsb1 = new BitVector.Builder(32)
				  .setByte(0, 0b1111_0101)
				  .setByte(1, 0b1000_1010)
				  .setByte(2, 0b1001_1000)
				  .setByte(3, 0b1110_1000)
				  .build();
		
		LcdImageLine line1 = new LcdImageLine(v,v2,v.or(v2));
		LcdImageLine line2 = new LcdImageLine(v3,v4,v3.or(v4));
		LcdImageLine line3 = line1.below(line2, opacity);
		LcdImageLine line4 = line1.below(line2, opacity2);
		LcdImageLine line5 = line1.below(line2, opacity3);

		
		assertEquals(line3.msb().toString(),msb1.toString());
		assertEquals(line3.lsb().toString(),lsb1.toString());
		assertEquals(line4.msb().toString(),v3.toString());		
		assertEquals(line4.lsb().toString(),v4.toString());
		assertEquals(line5.msb().toString(),v.toString());		
		assertEquals(line5.lsb().toString(),v2.toString());


		


	}
}