/**
 *  @author Clément Petit (282626)
 *  @author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.component.memory;

import java.util.Objects;

import ch.epfl.gameboj.Preconditions;
import ch.epfl.gameboj.component.Component;

public final class RamController implements Component {

    private final Ram ctrldRam;
    private final int start;
    private final int end;

    /**
     * builds a new ram controller for the given ram, in the range given by the
     * given start and end addresses.
     * 
     * @param ram
     *            the ram to be controlled
     * @param startAddress
     *            the start address
     * @param endAddress
     *            the end address
     */
    public RamController(Ram ram, int startAddress, int endAddress) {
        ctrldRam = Objects.requireNonNull(ram);
        start = Preconditions.checkBits16(startAddress);
        end = Preconditions.checkBits16(endAddress);
        if ((endAddress - startAddress) > ram.size()) {
            throw new IllegalArgumentException();
        }
    }

    /**
     * builds a new ram controller that give access to the totality of the given
     * ram, from the given start address.
     * 
     * @param ram
     *            the ram to be controlled
     * @param startAddress
     *            the start address
     */
    public RamController(Ram ram, int startAddress) {
        this(ram, startAddress, startAddress + ram.size());
    }

    @Override
    public int read(int address) {
        Preconditions.checkBits16(address);
        if (address >= start && address < end) {
            return ctrldRam.read(address - start);
        } else {
            return NO_DATA;
        }
    }

    @Override
    public void write(int address, int data) {
        Preconditions.checkBits16(address);
        Preconditions.checkBits8(data);
        if (address >= start && address < end) {
            ctrldRam.write(address - start, data);
        }

    }

}
