/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.gui;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import ch.epfl.gameboj.GameBoy;
import ch.epfl.gameboj.component.Joypad.Key;
import ch.epfl.gameboj.component.cartridge.Cartridge;
import ch.epfl.gameboj.component.lcd.LcdController;
import ch.epfl.gameboj.component.lcd.LcdImage;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Paint;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Button;
import javafx.scene.layout.CornerRadii;
import javafx.geometry.Insets;

/**
 * contains the simulator's main program.
 */
public final class Main extends Application {
    
    private GameBoy gb;

    private static final int ENLARGEMENT_FACTOR = 2;
    private static final int MEDIUM_BUTTON_SIZE = 67;

    private static final Map<KeyCode, Key> KEYS = Map.of(KeyCode.D, Key.RIGHT,
            KeyCode.A, Key.LEFT, KeyCode.W, Key.UP, KeyCode.S, Key.DOWN,
            KeyCode.O, Key.A, KeyCode.K, Key.B, KeyCode.B, Key.SELECT,
            KeyCode.N, Key.START);

    private boolean showTiles;
    
    private int screenshotNumber;
    
    private int videoNumber;
    private String videoName;
    
    private boolean recording;
    private int recordingSize;
    
    /**
     * calls the method launch of Application with the given argument.
     * 
     * @param args
     *            the arguments
     */
    public static void main(String[] args) {
        Application.launch(args);
    }

    /**
     * Checks that only one argument has been passed to the program (the name of
     * a ROM file) and finish the execution otherwise.
     * Creates a Game Boy whose cartridge is obtained from the ROM file passed in argument.
     * Creates the graphical interface and then displays it on the screen.
     * Simulates the Game Boy by periodically updating the image displayed on 
     * the screen and reacting to the key presses corresponding to those of the Game Boy.
     * Simulates different options on the emulator with a toolBar and Buttons.
     */
    @Override
    public void start(Stage stage) throws Exception {

        List<String> argList = getParameters().getRaw();

        if (argList.size() != 1)
            System.exit(1);

        File romFile = new File(argList.get(0));
        gb = new GameBoy(Cartridge.ofFile(romFile));
        
        showTiles = false;
        recording = false;
        
        int windowWidth = LcdController.LCD_WIDTH * ENLARGEMENT_FACTOR;
        int windowHeight = LcdController.LCD_HEIGHT * ENLARGEMENT_FACTOR;

        ImageView imageView = new ImageView();
        imageView.setFitWidth(windowWidth);
        imageView.setFitHeight(windowHeight);
        
        ImageView tilesImageView = new ImageView();
        tilesImageView.setFitWidth(windowWidth);
        tilesImageView.setFitHeight(windowWidth);
        
        double stageHeightAdjust = tilesImageView.getFitHeight() - imageView.getFitHeight();

        imageView.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                if (KEYS.get(event.getCode()) != null)
                    gb.joypad().keyPressed(KEYS.get(event.getCode()));
            }
        });

        imageView.setOnKeyReleased(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                if (KEYS.get(event.getCode()) != null)
                    gb.joypad().keyReleased(KEYS.get(event.getCode()));
            }
        });

        BorderPane borderPane = new BorderPane(imageView);
        borderPane.setBackground(new Background((new BackgroundFill(
                Paint.valueOf("90922CFF"), CornerRadii.EMPTY, Insets.EMPTY))));
        
        Button saveButton = new Button("Save");
        saveButton.setMinWidth(MEDIUM_BUTTON_SIZE);
        saveButton.setOnAction(e -> {
            saveProgress();
            borderPane.getCenter().requestFocus();
        }
        );
        
        Button screenshotButton = new Button("Screenshot");
        screenshotButton.setOnAction(e -> {
            screenshot();
            borderPane.getCenter().requestFocus();
        }
        );
        
        Button recordButton = new Button("Record");
        recordButton.setMinWidth(MEDIUM_BUTTON_SIZE);
        recordButton.setOnAction(e -> {
            if (!recording) {
                    createVideo();
            } else {
                recording = false;
                System.out.println(
                        "Recording ends : size = " + recordingSize/3);
            }
            recordingSize = 0;
            borderPane.getCenter().requestFocus();
        }
        );
        
        Button tilesButton = new Button("Tiles");
        tilesButton.setMinWidth(MEDIUM_BUTTON_SIZE);
        tilesButton.setOnAction(e -> {
                showTiles = !showTiles;
                stage.setWidth((showTiles ? 2 : 0.5) * stage.getWidth());
                stage.setHeight(stage.getHeight() + (showTiles ? stageHeightAdjust : -stageHeightAdjust));
                borderPane.setRight(showTiles ? tilesImageView : null);
                borderPane.getCenter().requestFocus();
            }
        );
        
        ToolBar toolBar = new ToolBar(saveButton,
                screenshotButton,
                recordButton,
                tilesButton
                );
        toolBar.setBackground(new Background((new BackgroundFill(
                Paint.valueOf("90922CFF"), CornerRadii.EMPTY, Insets.EMPTY))));
        borderPane.setTop(toolBar);
        
        stage.setScene(new Scene(borderPane));
        stage.setTitle("Gameboj");
        stage.show();
        imageView.requestFocus();

        long start = System.nanoTime();
        
        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                gb.runUntil(
                        (long) ((now - start) * GameBoy.CYCLES_PER_NANOSECOND));
                
                imageView.setImage(
                        ImageConverter
                        .convert(gb.lcdController().currentImage())
                        );
                
                if (showTiles)
                    tilesImageView.setImage(
                            ImageConverter
                            .convert(gb.lcdController().tilesImage())
                            );
                
                if (recording)
                    record();
            }
        };
        timer.start();
    }
    
    /**
     * converts a given LcdImage into a BufferedImage.
     * @param li the lcdImage image to be converted
     * @return a BufferedImage
     */
    private static BufferedImage convertLcdToBufferedImage(LcdImage li) {
        int[] COLOR_MAP = ImageConverter.COLOR_MAP;
        
        BufferedImage i = new BufferedImage(li.width(), li.height(),
                BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < li.height(); ++y)
            for (int x = 0; x < li.width(); ++x)
                i.setRGB(x, y, COLOR_MAP[li.get(x, y)]);
        
        return i;
    }

    /**
     * writes the current image displayed on the Game boy into a new file,
     * and puts this file into a folder "Screenshots", if the limit of 10000
     * screenshots is not exceeded. 
     */
    private void screenshot() {
        screenshotNumber = 0;
        File folder = new File("Screenshots");
        folder.mkdir();
        
        try {
            while (new File(folder.getName() + "/screenshot_"
                    + String.format("%04d", screenshotNumber) + ".png")
                    .exists())
                screenshotNumber++;
            
            if (screenshotNumber > 9999)
                throw new OutOfMemoryError();
            
            String screenshotName = "screenshot_"
                    + String.format("%04d", screenshotNumber);
            
            LcdImage li = gb.lcdController().currentImage();
            BufferedImage image = convertLcdToBufferedImage(li);
        
            ImageIO.write(image, "png",
                    new File(folder + "/" + screenshotName + ".png"));
            
            System.out.println("screenshot saved : " + screenshotName);
            
        } catch (IOException e) {
            System.err.println("Screenshot could not be saved");
            e.printStackTrace();
        } catch (OutOfMemoryError error) {
            System.err.println("Memory Full, screenshot could not be saved.");
        }
    }

    /**
     * creates a file named as a video in the folder "Video_recordings" if the limit
     * of 100 videos is not exceeded and pass "recording" to true, to enable the recording.
     */
    private void createVideo() throws OutOfMemoryError{
        videoNumber = 0;
        
        try {
            while (new File("Video_Recordings/Video_"
                    + String.format("%02d", videoNumber)).exists()) {
                videoNumber++;
            }
            if (videoNumber > 9999)
                throw new OutOfMemoryError();
            
            videoName = "Video_" + String.format("%02d", videoNumber);
            
            File video = new File("Video_Recordings/" + videoName);
            video.mkdirs();
            
            System.out.println("video : " + videoName);
            System.out.println("Recording starts");
            
            recording = true;
            
        } catch(OutOfMemoryError error) {
            System.err.println("Memory Full, video could not be recorded.");
        }
    }
    
    /**
     * gets the current image displayed on the Game Boy converted into a Buffered Image and
     * puts it in the last created video file if the limits are not exceeded.
     */
    private void record() {
        try {
            if (recordingSize/3 == 9999) {
                recording = false;
                throw new OutOfMemoryError();
            }  
            recordingSize++;
            
            if (recordingSize % 3 == 0) {
                LcdImage li = gb.lcdController().currentImage();
                BufferedImage image = convertLcdToBufferedImage(li);
                String imageName = "gameboj_" + String.format("%04d", recordingSize/3);
                
                ImageIO.write(image, "png", new File(
                        "Video_Recordings/" + videoName + "/" + imageName + ".png"));
            }
                
        } catch (IOException e) {
            System.err.println("An error occured during the recording");
            e.printStackTrace();
        } catch (OutOfMemoryError error) {
            System.err.println("Memory Full, could not proceed the recording.");
        }
    }

    /**
     * calls the method save of the Game Boy's cartridge.
     */
    private void saveProgress() { // save extension (see also : Cartridge and MSB1)
        gb.cartridge().save();
    }

}
