/**
 *  @author Clément Petit (282626)
 *  @author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.gui;

import ch.epfl.gameboj.component.lcd.LcdImage;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.image.PixelWriter;

/**
 * represents a converter of Game Boy images into JavaFX images.
 */
public final class ImageConverter {
    /**
     * The palette representing the 4 colours of the game boy display.
     */
    public static final int[] COLOR_MAP = new int[] { 0xFF_90_92_2C, 0xFF_6E_7F_43,
            0xFF_4A_5F_4C, 0xFF_36_49_3A };                                                 
    
    /**
     * converts the given LcdImage into a JavaFX image.
     * @param li the LcdImage
     * @return a JavaFX image
     */
    public static Image convert(LcdImage li) {
        
        WritableImage wi = new WritableImage(li.width(), li.height());
        PixelWriter pw = wi.getPixelWriter();
        
        for (int y = 0; y < li.height(); ++y)
            for (int x = 0; x < li.width(); ++x)
                pw.setArgb(x, y, COLOR_MAP[li.get(x, y)]);
        
        return wi;
    }
}