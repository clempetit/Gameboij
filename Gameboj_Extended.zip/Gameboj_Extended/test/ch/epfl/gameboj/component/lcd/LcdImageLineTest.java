/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.component.lcd;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Random;

import org.junit.jupiter.api.Test;

import ch.epfl.gameboj.bits.BitVector;
import ch.epfl.gameboj.bits.BitVector.Builder;
import ch.epfl.gameboj.bits.Bits;

public class LcdImageLineTest {
    private int posRnd;
    private int size;
    BitVector msb, lsb, opacity;

    LcdImageLine line;

    @Test
    void boucle() {
        for (int i = 0; i < 50; ++i) {
            posRnd = new Random().nextInt(100) + 1;
            size = posRnd * Integer.SIZE;
            line = new LcdImageLine(randomBitVector(), randomBitVector(), randomBitVector());
            msb = randomBitVector();
            lsb = randomBitVector();
            opacity = randomBitVector();
            line = new LcdImageLine(msb, lsb, opacity);
        
            constuctor();
            size();
            size_msb_Lsb_Opacity();
            shift() ;
            extractWrapped();
            mapColors();
            below();
            below2();
            join();
            equalsOverridingLcdImageLine();
            testBuilder() ;
        }
    }

    private BitVector randomBitVector() {

        BitVector.Builder randomBitVector = new Builder(Integer.SIZE * posRnd);
        for (int i = 0; i < 4 * posRnd; ++i)
            randomBitVector.setByte(i, Bits.clip(8, new Random().nextInt(0b11111111)));
        return randomBitVector.build();
    }

    private LcdImageLine randomLine() {
        return new LcdImageLine(randomBitVector(), randomBitVector(), randomBitVector());
    }

    
    void constuctor() {
        assertEquals(msb, line.msb());
        assertEquals(lsb, line.lsb());
        assertEquals(opacity, line.opacity());
        assertThrows(IllegalArgumentException.class, () -> {
            new LcdImageLine(new BitVector(Integer.SIZE * (posRnd+1)), lsb, opacity);
        });
        assertThrows(NullPointerException.class, () -> {
            new LcdImageLine(null, null, null);
        });
    }

    
    void size() {

        assertEquals(size, line.size());

    }

    
    void size_msb_Lsb_Opacity() {

        assertEquals(size, line.size());
        assertEquals(msb, line.msb());
        assertEquals(lsb, line.lsb());
        assertEquals(opacity, line.opacity());

    }

    
    void shift() {

        LcdImageLine b = line.shift(posRnd);
        LcdImageLine b1 = line.shift(-posRnd);

        assertEquals(msb.shift(posRnd), b.msb());
        assertEquals(msb.shift(-posRnd), b1.msb());

        assertEquals(lsb.shift(posRnd), b.lsb());
        assertEquals(lsb.shift(-posRnd), b1.lsb());

        assertEquals(opacity.shift(posRnd), b.opacity());
        assertEquals(opacity.shift(-posRnd), b1.opacity());

    }

    
    void extractWrapped() {

        LcdImageLine b = line.extractWrapped(size, posRnd);
        LcdImageLine b1 = line.extractWrapped(size, -posRnd);

        assertEquals(msb.extractWrapped(size, posRnd), b.msb());
        assertEquals(msb.extractWrapped(size, -posRnd), b1.msb());

        assertEquals(lsb.extractWrapped(size, posRnd), b.lsb());
        assertEquals(lsb.extractWrapped(size, -posRnd), b1.lsb());

        assertEquals(opacity.extractWrapped(size, posRnd), b.opacity());
        assertEquals(opacity.extractWrapped(size, -posRnd), b1.opacity());

    }

    
    void mapColors() {
        int color = new Random().nextInt(0b11111111);
        LcdImageLine line = randomLine();

        for (int i = 0; i < line.size(); ++i) {

            if (line.msb().testBit(i)) {
                if (line.lsb().testBit(i)) {
                    assertEquals(Bits.test(color, 7), line.mapColors(color).msb().testBit(i));
                    assertEquals(Bits.test(color, 6), line.mapColors(color).lsb().testBit(i));
                } else {
                    assertEquals(Bits.test(color, 5), line.mapColors(color).msb().testBit(i));
                    assertEquals(Bits.test(color, 4), line.mapColors(color).lsb().testBit(i));
                }
            } else {
                if (line.lsb().testBit(i)) {
                    assertEquals(Bits.test(color, 3), line.mapColors(color).msb().testBit(i));
                    assertEquals(Bits.test(color, 2), line.mapColors(color).lsb().testBit(i));
                } else {
                    assertEquals(Bits.test(color, 1), line.mapColors(color).msb().testBit(i));
                    assertEquals(Bits.test(color, 0), line.mapColors(color).lsb().testBit(i));
                }
            }

        }
    }

    

    void below() {
        LcdImageLine lineUp = randomLine();
        LcdImageLine lineDown = randomLine();

        for (int i = 0; i < size; ++i) {
            if (lineUp.opacity().testBit(i)) {
                assertEquals(lineUp.msb().testBit(i), lineDown.below(lineUp).msb().testBit(i));
                assertEquals(lineUp.lsb().testBit(i), lineDown.below(lineUp).lsb().testBit(i));
                assertEquals(true, lineDown.below(lineUp).opacity().testBit(i));
            } else {
                assertEquals(lineDown.msb().testBit(i), lineDown.below(lineUp).msb().testBit(i));
                assertEquals(lineDown.lsb().testBit(i), lineDown.below(lineUp).lsb().testBit(i));
                if (lineDown.opacity().testBit(i)) {
                    assertEquals(true, lineDown.below(lineUp).opacity().testBit(i));
                } else {
                    assertEquals(false, lineDown.below(lineUp).opacity().testBit(i));
                }
            }
        }
    }


    void below2() {
        LcdImageLine lineUp = randomLine();
        LcdImageLine lineDown = randomLine();
        BitVector opacityT = randomBitVector();
        for (int i = 0; i < size; ++i) {
            if (opacityT.testBit(i)) {
                assertEquals(lineUp.msb().testBit(i), lineDown.below(lineUp, opacityT).msb().testBit(i));
                assertEquals(lineUp.lsb().testBit(i), lineDown.below(lineUp, opacityT).lsb().testBit(i));
                assertEquals(true, lineDown.below(lineUp, opacityT).opacity().testBit(i));
            } else {
                assertEquals(lineDown.msb().testBit(i), lineDown.below(lineUp, opacityT).msb().testBit(i));
                assertEquals(lineDown.lsb().testBit(i), lineDown.below(lineUp, opacityT).lsb().testBit(i));
                if (lineDown.opacity().testBit(i)) {
                    assertEquals(true, lineDown.below(lineUp, opacityT).opacity().testBit(i));
                } else {
                    assertEquals(false, lineDown.below(lineUp, opacityT).opacity().testBit(i));
                }
            }
        }
    }

    
    void join() {

        LcdImageLine line1 = randomLine();
        LcdImageLine line0 = randomLine();

        for (int i = 0; i < posRnd; ++i) {
            assertEquals(line1.msb().testBit(i), line1.join(line0, posRnd).msb().testBit(i));
            assertEquals(line1.lsb().testBit(i), line1.join(line0, posRnd).lsb().testBit(i));
            assertEquals(line1.opacity().testBit(i), line1.join(line0, posRnd).opacity().testBit(i));
        }
        for (int i = posRnd; i < size; ++i) {
            assertEquals(line0.msb().testBit(i), line1.join(line0, posRnd).msb().testBit(i));
            assertEquals(line0.lsb().testBit(i), line1.join(line0, posRnd).lsb().testBit(i));
            assertEquals(line0.opacity().testBit(i), line1.join(line0, posRnd).opacity().testBit(i));
        }
    }

    
    void equalsOverridingLcdImageLine() {

        assertEquals(true, line.equals(new LcdImageLine(line.msb(), line.lsb(), line.opacity())));
        assertEquals(false, line.equals(new LcdImageLine(line.lsb(), line.msb(), line.opacity())));
    }

    
    void testBuilder() {
        LcdImageLine.Builder lineb = new LcdImageLine.Builder(size);
        BitVector.Builder vectb = new BitVector.Builder(size);

        for (int i = 0; i < size / 8; ++i) {
            int a = new Random().nextInt(0b11111111);
            lineb.setBytes(i, a, a);
            vectb.setByte(i, a);
        }
        BitVector vect = vectb.build();
        LcdImageLine line = lineb.build();
        assertEquals(vect, line.msb());
        assertEquals(vect, line.lsb());
        assertEquals(vect, line.opacity());

    }

}
