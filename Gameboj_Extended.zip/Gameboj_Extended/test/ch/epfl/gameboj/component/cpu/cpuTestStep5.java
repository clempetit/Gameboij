/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.component.cpu;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ch.epfl.gameboj.AddressMap;
import ch.epfl.gameboj.Bus;
import ch.epfl.gameboj.component.cpu.Cpu;
import ch.epfl.gameboj.component.cpu.Cpu.Interrupt;
import ch.epfl.gameboj.component.cpu.Opcode;
import ch.epfl.gameboj.component.memory.Ram;
import ch.epfl.gameboj.component.memory.RamController;

class cpuTestStep5 {



    void afficher(Cpu cpu) {
        int[] tab = cpu._testGetPcSpAFBCDEHL();
        System.out.println("PC : " + tab[0]);
        System.out.println("SP: " + tab[1]);
        System.out.println("A : " + tab[2]);
        System.out.println("F : " + tab[3]);
        System.out.println("B : " + tab[4]);
        System.out.println("C : " + tab[5]);
        System.out.println("D : " + tab[6]);
        System.out.println("E : " + tab[7]);
        System.out.println("H : " + tab[8]);
        System.out.println("L : " + tab[9]);
    }

    void run(Cpu cpu , int a) {
        for (int i = 0; i < a; ++i) {
            cpu.cycle(i);
        }
    }
    
    byte[] fibTab = new byte[] {
            (byte)0x31, (byte)0xFF, (byte)0xFF, (byte)0x3E,
            (byte)0x0B, (byte)0xCD, (byte)0x0A, (byte)0x00,
            (byte)0x76, (byte)0x00, (byte)0xFE, (byte)0x02,
            (byte)0xD8, (byte)0xC5, (byte)0x3D, (byte)0x47,
            (byte)0xCD, (byte)0x0A, (byte)0x00, (byte)0x4F,
            (byte)0x78, (byte)0x3D, (byte)0xCD, (byte)0x0A,
            (byte)0x00, (byte)0x81, (byte)0xC1, (byte)0xC9,
            };
    
    @Test
    void VBLANK() { // A += n Z0HC
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);

        cpu.attachTo(bus);
        rc.attachTo(bus);

        bus.write(0, Opcode.EI.encoding);
        cpu.requestInterrupt(Interrupt.VBLANK);
        bus.write(0x40, 0b00_111_110);
        bus.write(0x40  + 1 , 10);
        bus.write(AddressMap.REG_IE, 0b00_00_00__01);



        for (int i = 0; i<=60; i++) {
        run(cpu , i);
        System.out.println(cpu._testGetPcSpAFBCDEHL()[0]);
        }
        System.out.println("START");
        System.out.println("A= "+cpu._testGetPcSpAFBCDEHL()[2]);
        
        assertEquals(10, cpu._testGetPcSpAFBCDEHL()[2]);


    }
    
    

    @Test
    void HALT() { // A += n Z0HC
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);

        cpu.attachTo(bus);
        rc.attachTo(bus);
        bus.write(0, Opcode.EI.encoding);
        bus.write(1, Opcode.HALT.encoding);
        bus.write(2, 0b00_111_110);
        bus.write(3 , 10);
        run(cpu , 40);
        afficher(cpu);
        cpu.requestInterrupt(Interrupt.VBLANK);
        bus.write(0x40, Opcode.LD_A_N8.encoding);
        bus.write(65, 10);
        bus.write(AddressMap.REG_IE, 0b00_00_00__01);
        run(cpu , 80);
        System.out.println("RUN");
        System.out.println("A "+cpu._testGetPcSpAFBCDEHL()[2]);
        afficher(cpu);
        
        assertEquals(10, cpu._testGetPcSpAFBCDEHL()[2]);


    }
    
    
    @Test
    void Write_read() { // A += n Z0HC
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);

        cpu.attachTo(bus);
        rc.attachTo(bus);

        bus.write(AddressMap.REG_IF, 10);
        bus.write(AddressMap.REG_IE, 99);
        bus.write(AddressMap.HIGH_RAM_START + 10 , 88);
        
        assertEquals(10, cpu.read(AddressMap.REG_IF));
        assertEquals(10, bus.read(AddressMap.REG_IF));
        
        assertEquals(99, cpu.read(AddressMap.REG_IE));
        assertEquals(99, bus.read(AddressMap.REG_IE));

        assertEquals(88, bus.read(AddressMap.HIGH_RAM_START + 10 ));
        assertEquals(88, cpu.read(AddressMap.HIGH_RAM_START + 10 ));
        assertEquals(256 , cpu.read(10));
    }
    
    
    @Test
    void VBLANK_AND_RETI() { 
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);

        cpu.attachTo(bus);
        rc.attachTo(bus);

        bus.write(0, Opcode.EI.encoding);
        cpu.requestInterrupt(Interrupt.VBLANK);
        
        bus.write(1, 0b00_111_110);
        bus.write(2  , 110);
        
        
        bus.write(0x40, 0b00_111_110);
        bus.write(65 , 10);
        bus.write(66, Opcode.RETI.encoding);
        
        bus.write(AddressMap.REG_IE, 0b00_00_00__01);
        
        
        run(cpu , 60);


        
        assertEquals(110, cpu._testGetPcSpAFBCDEHL()[2]);


    }

    

    
    
    
    
    @Test
    void FIB() { // A += n Z0HC
        Cpu cpu = new Cpu();
        Bus bus = new Bus();
        Ram ram = new Ram(0xFFFF);
        RamController rc = new RamController(ram, 0);

        cpu.attachTo(bus);
        rc.attachTo(bus);

        
        for (int i = 0 ;  i < fibTab.length ; ++i)
        {
            bus.write(i, Byte.toUnsignedInt(fibTab[i]));
        }

        run(cpu , 100000);


        assertEquals(89, cpu._testGetPcSpAFBCDEHL()[2]);
    }

}