/**
 *	@author Clément Petit (282626)
 *	@author Yanis Berkani (271348)
 */

package ch.epfl.gameboj.component.cpu;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ch.epfl.gameboj.Bus;
import ch.epfl.gameboj.bits.Bits;
import ch.epfl.gameboj.component.cpu.Cpu;
import ch.epfl.gameboj.component.cpu.Opcode;
import ch.epfl.gameboj.component.memory.Ram;
import ch.epfl.gameboj.component.memory.RamController;

class CpuTest3 {

    Bus bus = new Bus();
    Cpu cpu = new Cpu();
    Ram ram = new Ram(0xFFFF);
    Opcode[] tab = {};//Cpu.buildOpcodeTable(Opcode.Kind.DIRECT);
    RamController ramC = new RamController(ram, 0);

    private void attach() {
        cpu.attachTo(bus);
        ramC.attachTo(bus);
    }

    void printAllValues() {

        System.out.println("PC : " + cpu._testGetPcSpAFBCDEHL()[0]);
        System.out.println("SP : " + cpu._testGetPcSpAFBCDEHL()[1]);
        System.out.println("A : " + cpu._testGetPcSpAFBCDEHL()[2]);
        System.out.println("F : " + cpu._testGetPcSpAFBCDEHL()[3]);
        System.out.println("B : " + cpu._testGetPcSpAFBCDEHL()[4]);
        System.out.println("C : " + cpu._testGetPcSpAFBCDEHL()[5]);
        System.out.println("D : " + cpu._testGetPcSpAFBCDEHL()[6]);
        System.out.println("E : " + cpu._testGetPcSpAFBCDEHL()[7]);
        System.out.println("H : " + cpu._testGetPcSpAFBCDEHL()[8]);
        System.out.println("L : " + cpu._testGetPcSpAFBCDEHL()[9]);

    }

    private int[] val() {
        return cpu._testGetPcSpAFBCDEHL();
    }

    private void resetBus() {
        for(int i = 0; i<=0xFFFF;i++) {
            bus.write(i, 0);
        }
        
    }
    
    @Test
    void LD_R8_HLRandUworkOnNonTrivialValues() {
        attach();

        bus.write(0, 0x2a);
        cpu.cycle(0); // L = 1; A = 42

        bus.write(tab[0x2a].totalBytes, 0x46);
        cpu.cycle(tab[0x2a].cycles); // B = BUS[42] = 70

        assertEquals(2, val()[0]);
        assertEquals(42, val()[2]);
        assertEquals(70, val()[4]);
        assertEquals(1, val()[9]);

        //resetBus();
    }
    /**
     * LD A, [$FF00 + 0] /  / LD A, [$FF00 + $FF]
     */
    @Test
    void LD_A_N8RworksOnNonTrivialValues() {
        
        attach();
        
        bus.write(1 , 2);
        bus.write(0xFF00 + 2, 7);

        bus.write(0, Opcode.LD_A_N8R.encoding);
        cpu.cycle(0);
        assertEquals(7, val()[2]);
        //resetBus();
    }
    
    /**
     * LD A, [$FF00 + C]
     */
    @Test
    void LD_A_CRworksOnNonTrivialValues() {
        attach();
        bus.write(0xFF00, 4);
        bus.write(0, Opcode.LD_A_CR.encoding);
        cpu.cycle(0);
        assertEquals(4,val()[2]);
        //resetBus();
    }

    /**
     *  LD A, [0] /  / LD A, [$FFFF]
     */
    @Test
    void LD_A_N16RworksOnNonTrivialValues() {
        attach();
        bus.write(0, Opcode.LD_A_N16R.encoding);
        bus.write(1, 0b0000_0000);
        
        bus.write(2, 0b1111_1111);
        System.out.println(Bits.make16(bus.read( 2), bus.read(1)));
        System.out.println(0xFF00);
        bus.write(0xFF00, 5);
        cpu.cycle(0);
        assertEquals(5, val()[2]);
        
    }

}